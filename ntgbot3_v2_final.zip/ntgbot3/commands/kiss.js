"use strict";

const { createCanvas, loadImage } = require("canvas");
const axios = require("axios");
const path  = require("path");
const fs    = require("fs-extra");

const TMP = path.join(__dirname, "tmp");
fs.ensureDirSync(TMP);

const KISS_TEXTS = [
  "Sending love! 💋",
  "So sweet! 😘",
  "Awww! 🥰",
  "Love is real! ❤️",
  "Kiss! 💕",
];

async function loadAvatar(url) {
  const res = await axios.get(url, { responseType: "arraybuffer", timeout: 10000 });
  return loadImage(Buffer.from(res.data));
}

async function getProfilePicUrl(info) {
  return info?.hd_profile_pic_url_info?.url || info?.profile_pic_url || null;
}

module.exports = {
  config: {
    name:        "kiss",
    aliases:     ["smooch", "xoxo"],
    version:     "2.0",
    author:      "MD RIAD",
    cooldown:    5,
    role:        0,
    description: "Send a kiss to someone",
    category:    "fun",
    guide:       "{p}kiss @username",
  },

  langs: {
    en: {
      noTarget: "❌ Mention someone to kiss!\nUsage: {p}kiss @username",
      notFound: "❌ User @%1 not found.",
      noPhoto:  "💋 %1 kissed %2!\n\n%3",
      result:   "💋 %1 kissed %2!\n\n%3",
      error:    "❌ Error: %1",
    },
  },

  onStart: async function ({ api, event, args, message, getLang }) {
    const { threadId, senderID } = event;
    const prefix = global.NTGBot.config.prefix;

    const rawTarget = args[0];
    if (!rawTarget) return message.reply(getLang("noTarget").replace("{p}", prefix));
    const targetUsername = rawTarget.replace(/^@/, "").trim();

    let info1, info2;
    try { info1 = await api.getUserInfo(senderID); }
    catch (e) { return message.reply(getLang("error", e.message)); }
    try { info2 = await api.getUserInfoByUsername(targetUsername); }
    catch (e) { return message.reply(getLang("notFound", targetUsername)); }

    const name1   = info1?.full_name || info1?.username || "User";
    const name2   = info2?.full_name || info2?.username  || targetUsername;
    const kissTxt = KISS_TEXTS[Math.floor(Math.random() * KISS_TEXTS.length)];

    const pic1url = await getProfilePicUrl(info1);
    const pic2url = await getProfilePicUrl(info2);

    if (!pic1url || !pic2url) {
      return message.reply(getLang("noPhoto", name1, name2, kissTxt));
    }

    try {
      const SIZE = 160;
      const W = 520, H = 280;

      const canvas = createCanvas(W, H);
      const ctx    = canvas.getContext("2d");

      // Soft pink gradient background
      const grad = ctx.createLinearGradient(0, 0, W, H);
      grad.addColorStop(0, "#ff9a9e");
      grad.addColorStop(1, "#fecfef");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);

      const [av1, av2] = await Promise.all([loadAvatar(pic1url), loadAvatar(pic2url)]);

      function drawCircleAvatar(img, x, y, size, ringColor = "#e91e8c") {
        ctx.save();
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(img, x, y, size, size);
        ctx.restore();
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
        ctx.strokeStyle = ringColor;
        ctx.lineWidth   = 5;
        ctx.stroke();
      }

      drawCircleAvatar(av1, 25,  60, SIZE, "#e91e8c");
      drawCircleAvatar(av2, W - SIZE - 25, 60, SIZE, "#e91e8c");

      // Floating hearts
      const hearts = ["💗", "💕", "💋", "💖", "❤️"];
      ctx.font      = "28px Arial";
      ctx.textAlign = "center";
      hearts.forEach((h, i) => {
        ctx.fillText(h, W / 2 - 30 + i * 15, 60 + (i % 2 === 0 ? 0 : 20));
      });

      // Big kiss emoji center
      ctx.font = "55px Arial";
      ctx.fillText("💋", W / 2, H / 2 + 30);

      // Names
      ctx.font      = "bold 17px Arial";
      ctx.fillStyle = "#6b0f3a";
      ctx.textAlign = "center";
      ctx.fillText(name1.slice(0, 14), 25 + SIZE / 2, H - 18);
      ctx.fillText(name2.slice(0, 14), W - SIZE / 2 - 25, H - 18);

      // Title
      ctx.font      = "bold 22px Arial";
      ctx.fillStyle = "#c2185b";
      ctx.fillText("KISS!", W / 2, 42);

      const outPath = path.join(TMP, `kiss_${senderID}_${Date.now()}.png`);
      fs.writeFileSync(outPath, canvas.toBuffer("image/png"));

      await api.sendPhotoFromUrl(threadId, `file://${outPath}`, {
        caption: getLang("result", name1, name2, kissTxt),
      }).catch(() => message.reply(getLang("noPhoto", name1, name2, kissTxt)));

      fs.unlinkSync(outPath);
    } catch (e) {
      message.reply(getLang("noPhoto", name1, name2, kissTxt));
    }
  },
};
