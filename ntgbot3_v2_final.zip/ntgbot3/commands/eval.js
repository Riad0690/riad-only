"use strict";

module.exports = {
  config: {
    name:        "eval",
    aliases:     ["exec", "js"],
    version:     "2.0",
    author:      "MD RIAD",
    cooldown:    0,
    role:        4,   // Developer only
    description: "Execute JavaScript code (Developer only)",
    category:    "dev",
    guide:       "{p}eval <js code>",
  },

  langs: {
    en: {
      noCode:  "❌ Provide code to evaluate.",
      result:  "✅ Result:\n%1",
      error:   "❌ Error:\n%1",
      timeout: "⏱️ Execution timed out (5s limit).",
    },
  },

  onStart: async function ({ event, args, message, getLang, api, bot }) {
    const code = args.join(" ");
    if (!code) return message.reply(getLang("noCode"));

    // Expose useful vars inside eval scope
    const NTGBot = bot;

    try {
      // Wrap in async to support await inside eval
      const fn  = new Function("api", "event", "NTGBot", "require",
        `return (async () => { ${code} })()`
      );
      const result = await Promise.race([
        fn(api, event, NTGBot, require),
        new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), 5000)),
      ]);

      const output = result !== undefined
        ? (typeof result === "object" ? JSON.stringify(result, null, 2) : String(result))
        : "(no return value)";

      message.reply(getLang("result", output.slice(0, 2000)));
    } catch (e) {
      if (e.message === "timeout") return message.reply(getLang("timeout"));
      message.reply(getLang("error", e.message));
    }
  },
};
