"use strict";

const https = require("https");

function askClaude(prompt) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 800,
      messages: [{ role: "user", content: prompt }],
    });
    const req = https.request({
      hostname: "api.anthropic.com",
      path: "/v1/messages",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY || "",
        "anthropic-version": "2023-06-01",
      },
    }, res => {
      let data = "";
      res.on("data", c => data += c);
      res.on("end", () => {
        try {
          const p = JSON.parse(data);
          if (p.error) return reject(new Error(p.error.message));
          resolve(p.content?.[0]?.text || "No response.");
        } catch { reject(new Error("Parse error")); }
      });
    });
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

module.exports = {
  config: {
    name: "ai",
    aliases: ["ask", "gpt", "claude"],
    version: "1.0",
    author: "MD RIAD",
    cooldown: 5,
    role: 0,
    description: "Ask Claude AI anything",
    usage: "ai <question>",
    category: "ai",
  },

  onStart: async function ({ api, event, args, getLang }) {
    const { threadId, messageId } = event;
    if (!args.length) return api.sendMessage(getLang("missingQuery"), threadId);
    if (!process.env.ANTHROPIC_API_KEY) return api.sendMessage(getLang("noApiKey"), threadId);
    await api.sendMessage(getLang("thinking"), threadId);
    try {
      const reply = await askClaude(args.join(" "));
      await api.sendMessage(getLang("result", reply), threadId);
    } catch (e) {
      await api.sendReaction("❌", messageId).catch(() => {});
      api.sendMessage(getLang("error", e.message), threadId);
    }
  },
};
