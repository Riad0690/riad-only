"use strict";

const { createCanvas, loadImage } = require("canvas");
const axios  = require("axios");
const path   = require("path");
const fs     = require("fs-extra");
const { getExp, getBalance, getAllUsers } = require("../utils/database");

const TMP = path.join(__dirname, "tmp");
fs.ensureDirSync(TMP);

// ── EXP / Level math ──────────────────────────────────────────────────────────
const DELTA = 5;
const expToLevel  = (exp)   => Math.floor((1 + Math.sqrt(1 + 8 * exp / DELTA)) / 2);
const levelToExp  = (level) => Math.floor(((level ** 2 - level) * DELTA) / 2);

// ── Build rank card ───────────────────────────────────────────────────────────
async function buildRankCard({ name, username, avatarUrl, exp, rank, total }) {
  const W = 900, H = 280;
  const canvas = createCanvas(W, H);
  const ctx    = canvas.getContext("2d");

  const level      = expToLevel(exp);
  const expCurrent = exp - levelToExp(level);
  const expNext    = levelToExp(level + 1) - levelToExp(level);
  const progress   = Math.min(expCurrent / expNext, 1);

  // ── Background ────────────────────────────────────────────────────────────
  const bg = ctx.createLinearGradient(0, 0, W, H);
  bg.addColorStop(0, "#0f0c29");
  bg.addColorStop(0.5, "#302b63");
  bg.addColorStop(1, "#24243e");
  ctx.fillStyle = bg;
  ctx.roundRect(0, 0, W, H, 20);
  ctx.fill();

  // ── Avatar ────────────────────────────────────────────────────────────────
  const AV_SIZE = 170, AV_X = 55, AV_Y = (H - AV_SIZE) / 2;

  if (avatarUrl) {
    try {
      const res = await axios.get(avatarUrl, { responseType: "arraybuffer", timeout: 10000 });
      const img = await loadImage(Buffer.from(res.data));

      // Circular clip
      ctx.save();
      ctx.beginPath();
      ctx.arc(AV_X + AV_SIZE / 2, AV_Y + AV_SIZE / 2, AV_SIZE / 2, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(img, AV_X, AV_Y, AV_SIZE, AV_SIZE);
      ctx.restore();
    } catch {}
  }

  // Avatar ring
  ctx.beginPath();
  ctx.arc(AV_X + AV_SIZE / 2, AV_Y + AV_SIZE / 2, AV_SIZE / 2 + 4, 0, Math.PI * 2);
  ctx.strokeStyle = "#7c83fd";
  ctx.lineWidth   = 5;
  ctx.stroke();

  // ── Text area ─────────────────────────────────────────────────────────────
  const TXT_X = AV_X + AV_SIZE + 40;

  // Name
  ctx.font      = "bold 34px Arial";
  ctx.fillStyle = "#ffffff";
  ctx.fillText(name.slice(0, 22), TXT_X, 80);

  // Username
  ctx.font      = "20px Arial";
  ctx.fillStyle = "#a0a0c0";
  ctx.fillText(`@${username}`.slice(0, 28), TXT_X, 112);

  // Level badge
  ctx.font      = "bold 28px Arial";
  ctx.fillStyle = "#7c83fd";
  ctx.fillText(`LVL ${level}`, TXT_X, 158);

  // Rank
  ctx.font      = "22px Arial";
  ctx.fillStyle = "#ffd700";
  ctx.fillText(`Rank #${rank} / ${total}`, TXT_X + 160, 158);

  // EXP text
  ctx.font      = "18px Arial";
  ctx.fillStyle = "#c0c0e0";
  ctx.fillText(`EXP: ${expCurrent} / ${expNext}`, TXT_X, 195);

  // ── XP Bar ───────────────────────────────────────────────────────────────
  const BAR_X = TXT_X, BAR_Y = 215, BAR_W = W - TXT_X - 55, BAR_H = 22;

  // Bar background
  ctx.fillStyle = "rgba(255,255,255,0.1)";
  ctx.roundRect(BAR_X, BAR_Y, BAR_W, BAR_H, BAR_H / 2);
  ctx.fill();

  // Bar fill (gradient)
  if (progress > 0) {
    const barGrad = ctx.createLinearGradient(BAR_X, 0, BAR_X + BAR_W, 0);
    barGrad.addColorStop(0, "#7c83fd");
    barGrad.addColorStop(1, "#c471ed");
    ctx.fillStyle = barGrad;
    ctx.roundRect(BAR_X, BAR_Y, BAR_W * progress, BAR_H, BAR_H / 2);
    ctx.fill();
  }

  // Progress percent
  ctx.font      = "bold 14px Arial";
  ctx.fillStyle = "#ffffff";
  ctx.textAlign = "center";
  ctx.fillText(`${Math.round(progress * 100)}%`, BAR_X + BAR_W / 2, BAR_Y + BAR_H - 4);
  ctx.textAlign = "left";

  return canvas.toBuffer("image/png");
}

// ── Command ───────────────────────────────────────────────────────────────────
module.exports = {
  config: {
    name:        "rank",
    aliases:     ["level", "xp", "lvl"],
    version:     "2.0",
    author:      "MD RIAD",
    cooldown:    5,
    role:        0,
    description: "View your rank card or someone else's",
    category:    "rank",
    guide:       "{p}rank  |  {p}rank @username",
  },

  langs: {
    en: {
      noUsers:  "No rank data yet. Start chatting to earn EXP!",
      notFound: "❌ User @%1 not found.",
      error:    "❌ Error: %1",
      fallback: "📊 Rank Card\n──────────────\n👤 %1 (@%2)\n⭐ Level: %3\n🔢 EXP: %4\n🏆 Rank: #%5 / %6",
    },
  },

  // onChat — every message gives +1 EXP to sender
  onChat: async function ({ event }) {
    try {
      const { addExp } = require("../utils/database");
      await addExp(event.senderID, 1);
    } catch {}
  },

  onStart: async function ({ api, event, args, message, getLang }) {
    const { threadId, senderID } = event;

    // Determine target
    const rawTarget = args[0]?.replace(/^@/, "").trim();
    let targetID    = senderID;
    let userInfo;

    try {
      if (rawTarget) {
        userInfo = await api.getUserInfoByUsername(rawTarget);
        targetID = userInfo?.pk || userInfo?.id || senderID;
      } else {
        userInfo = await api.getUserInfo(senderID);
      }
    } catch (e) {
      if (rawTarget) return message.reply(getLang("notFound", rawTarget));
      return message.reply(getLang("error", e.message));
    }

    const name     = userInfo?.full_name || userInfo?.username || "Unknown";
    const username = userInfo?.username  || String(targetID);
    const avatarUrl =
      userInfo?.hd_profile_pic_url_info?.url ||
      userInfo?.profile_pic_url             ||
      null;

    // Get exp + rank
    const exp      = await getExp(targetID);
    const allUsers = await getAllUsers();
    allUsers.sort((a, b) => (b.exp || 0) - (a.exp || 0));
    const rank     = allUsers.findIndex(u => String(u.uid) === String(targetID)) + 1 || allUsers.length;
    const total    = allUsers.length || 1;
    const level    = expToLevel(exp);

    try {
      const imgBuf  = await buildRankCard({ name, username, avatarUrl, exp, rank, total });
      const outPath = path.join(TMP, `rank_${targetID}_${Date.now()}.png`);
      fs.writeFileSync(outPath, imgBuf);

      await api.sendPhotoFromUrl(threadId, `file://${outPath}`, {
        caption: `📊 ${name} — Level ${level} | Rank #${rank}/${total}`,
      }).catch(() => {
        message.reply(getLang("fallback", name, username, level, exp, rank, total));
      });

      fs.unlinkSync(outPath);
    } catch (e) {
      message.reply(getLang("fallback", name, username, level, exp, rank, total));
    }
  },
};
