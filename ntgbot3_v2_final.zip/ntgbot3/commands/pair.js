"use strict";

const jimp    = require("jimp");
const axios   = require("axios");
const path    = require("path");
const fs      = require("fs-extra");

const TMP = path.join(__dirname, "tmp");
fs.ensureDirSync(TMP);

// ── Helpers ───────────────────────────────────────────────────────────────────
const CAPTIONS = [
  "Made for each other 💑",
  "Perfect match 💘",
  "Soulmates forever 🌟",
  "Love is in the air 🌹",
  "Together always 💞",
  "Two hearts, one soul 🫶",
  "Written in the stars ✨",
];

const SCORES = [
  { min: 90, label: "Perfect 💯" },
  { min: 75, label: "Amazing 💫" },
  { min: 60, label: "Great 🌟" },
  { min: 45, label: "Good 👍" },
  { min: 0,  label: "Maybe 🤔" },
];

function compatLabel(pct) {
  return SCORES.find(s => pct >= s.min)?.label || "Maybe 🤔";
}

async function getProfilePic(userInfo) {
  // Instagram API returns multiple fields — try in priority order
  const url =
    userInfo?.hd_profile_pic_url_info?.url ||
    userInfo?.profile_pic_url             ||
    userInfo?.profile_pic_url_hd          ||
    null;
  return url;
}

async function fetchAvatar(url) {
  const res = await axios.get(url, { responseType: "arraybuffer", timeout: 10000 });
  return jimp.read(Buffer.from(res.data));
}

// ── Command ───────────────────────────────────────────────────────────────────
module.exports = {
  config: {
    name:        "pair",
    aliases:     ["couple", "love"],
    version:     "2.0",
    author:      "MD RIAD",
    cooldown:    10,
    role:        0,
    description: "Pair two users with their Instagram profile photos",
    category:    "fun",
    guide:       "{p}pair @username  — pairs you with the mentioned user",
  },

  langs: {
    en: {
      noTarget:   "❌ Please mention a username!\nUsage: {p}pair @username",
      noPhoto:    "⚠️ Could not load one or both profile photos.\n%1 x %2\n\n%3",
      result:     "%1 x %2\n\n💘 Love: %3%\n🌟 Compatibility: %4\n\n%5",
      error:      "❌ Error: %1",
      notFound:   "❌ User @%1 not found.",
    },
  },

  onStart: async function ({ api, event, args, message, getLang }) {
    const { threadId, senderID } = event;
    const prefix = global.NTGBot.config.prefix;

    // ── Get target username ───────────────────────────────────────────────
    const rawTarget = args[0];
    if (!rawTarget) {
      return message.reply(getLang("noTarget").replace("{p}", prefix));
    }
    const targetUsername = rawTarget.replace(/^@/, "").trim();

    // ── Fetch both user infos ─────────────────────────────────────────────
    let info1, info2;
    try {
      info1 = await api.getUserInfo(senderID);
    } catch (e) {
      return message.reply(getLang("error", e.message));
    }
    try {
      info2 = await api.getUserInfoByUsername(targetUsername);
    } catch (e) {
      return message.reply(getLang("notFound", targetUsername));
    }

    const name1 = info1?.full_name || info1?.username || "User 1";
    const name2 = info2?.full_name || info2?.username  || targetUsername;

    // ── Random scores ─────────────────────────────────────────────────────
    const lovePct   = Math.floor(Math.random() * 51) + 50; // 50–100
    const compatPct = Math.floor(Math.random() * 51) + 50;
    const caption   = CAPTIONS[Math.floor(Math.random() * CAPTIONS.length)];

    // ── Try to get profile pics ───────────────────────────────────────────
    const pic1url = await getProfilePic(info1);
    const pic2url = await getProfilePic(info2);

    if (!pic1url || !pic2url) {
      return message.reply(
        getLang("noPhoto", name1, name2, caption)
      );
    }

    // ── Build image with jimp ─────────────────────────────────────────────
    try {
      const SIZE   = 200;
      const PAD    = 20;
      const GAP    = 60;   // gap between circles
      const W      = SIZE * 2 + GAP + PAD * 2;
      const H      = SIZE + PAD * 2;

      const [img1, img2] = await Promise.all([
        fetchAvatar(pic1url),
        fetchAvatar(pic2url),
      ]);

      // Resize both to square
      img1.resize(SIZE, SIZE);
      img2.resize(SIZE, SIZE);

      // Make circular masks using jimp built-in
      img1.circle();
      img2.circle();

      // Canvas — pink/purple gradient background via jimp solid color
      const BG_COLOR = 0xff69b4ff; // hot pink
      const canvas   = new jimp(W, H, BG_COLOR);

      // Composite avatars
      canvas.composite(img1, PAD,                PAD);
      canvas.composite(img2, PAD + SIZE + GAP,   PAD);

      // Heart emoji in middle (text overlay)
      const font = await jimp.loadFont(jimp.FONT_SANS_32_WHITE);
      canvas.print(font, PAD + SIZE + 10, PAD + SIZE / 2 - 20, "💗");

      // Save to tmp
      const outPath = path.join(TMP, `pair_${senderID}_${Date.now()}.png`);
      await canvas.writeAsync(outPath);

      // Send photo
      await api.sendPhotoFromUrl(threadId, `file://${outPath}`, {
        caption: getLang("result", name1, name2, lovePct, compatLabel(compatPct), caption),
      }).catch(() => {
        // Fallback: send as text if photo fails
        message.reply(getLang("result", name1, name2, lovePct, compatLabel(compatPct), caption));
      });

      fs.unlinkSync(outPath);

    } catch (e) {
      // Image build failed — send text version
      message.reply(getLang("result", name1, name2, lovePct, compatLabel(compatPct), caption));
    }
  },
};
