"use strict";

module.exports = {
  config: {
    name: "help",
    aliases: ["h", "cmds"],
    version: "1.0",
    author: "MD RIAD",
    cooldown: 3,
    role: 0,
    description: "View command list or details",
    usage: "help [page | command name]",
    category: "info",
  },

  onStart: async function ({ api, event, args, getLang }) {
    const { threadId } = event;
    const prefix = global.NTGBot.config.prefix;
    const commands = global.NTGBot.commands;

    if (args[0]) {
      const cmd = commands.get(args[0].toLowerCase());
      if (!cmd) return api.sendMessage(getLang("commandNotFound", args[0]), threadId);
      const c = cmd.config;
      const roleText = c.role === 4 ? "Developer" : c.role === 3 ? "Premium" : c.role === 2 ? "Admin" : "Everyone";
      return api.sendMessage(
        `╭── NAME ────⭓\n│ ${prefix}${c.name}\n├── INFO\n│ Description: ${c.description || "N/A"}\n│ Aliases: ${c.aliases?.join(", ") || "None"}\n│ Version: ${c.version || "1.0"}\n│ Role: ${roleText}\n│ Cooldown: ${c.cooldown || 0}s\n│ Author: ${c.author || "Unknown"}\n│ Category: ${c.category || "general"}\n├── USAGE\n│ ${prefix}${c.usage || c.name}\n╰──────⭔`,
        threadId
      );
    }

    const cats = {};
    const seen = new Set();
    for (const [, cmd] of commands) {
      if (seen.has(cmd.config.name)) continue;
      seen.add(cmd.config.name);
      const cat = cmd.config.category || "general";
      if (!cats[cat]) cats[cat] = [];
      cats[cat].push(cmd.config.name);
    }

    let msg = `╭─────────────⭓\n│ 🤖 NTG Bot Commands\n│ Author: MD RIAD\n├─────⭔\n│ Prefix: ${prefix}\n│ Total: ${seen.size} commands\n├─────⭔\n`;
    for (const [cat, cmds] of Object.entries(cats)) {
      msg += `│ 📂 ${cat.toUpperCase()}\n`;
      msg += cmds.map(c => `│   ${prefix}${c}`).join("\n") + "\n";
    }
    msg += `╰─────────────⭓\n» Type ${prefix}help <name> for details`;

    api.sendMessage(msg, threadId);
  },
};
