"use strict";

const { createCanvas, loadImage } = require("canvas");
const axios  = require("axios");
const path   = require("path");
const fs     = require("fs-extra");

const TMP = path.join(__dirname, "tmp");
fs.ensureDirSync(TMP);

const SLAP_TEXTS = [
  "Got slapped! 👋",
  "That left a mark! 🤚",
  "Ouch! 😵",
  "Right in the face! 😤",
  "Slapped into next week! 💥",
];

async function loadAvatar(url) {
  const res = await axios.get(url, { responseType: "arraybuffer", timeout: 10000 });
  return loadImage(Buffer.from(res.data));
}

async function getProfilePicUrl(userInfo) {
  return (
    userInfo?.hd_profile_pic_url_info?.url ||
    userInfo?.profile_pic_url             ||
    null
  );
}

module.exports = {
  config: {
    name:        "slap",
    aliases:     ["hit", "smack"],
    version:     "2.0",
    author:      "MD RIAD",
    cooldown:    5,
    role:        0,
    description: "Slap someone with a generated image",
    category:    "fun",
    guide:       "{p}slap @username",
  },

  langs: {
    en: {
      noTarget:  "❌ Mention someone to slap!\nUsage: {p}slap @username",
      notFound:  "❌ User @%1 not found.",
      noPhoto:   "👋 %1 slapped %2!\n\n%3",
      result:    "👋 %1 slapped %2!\n\n%3",
      error:     "❌ Error: %1",
    },
  },

  onStart: async function ({ api, event, args, message, getLang }) {
    const { threadId, senderID } = event;
    const prefix = global.NTGBot.config.prefix;

    const rawTarget = args[0];
    if (!rawTarget) return message.reply(getLang("noTarget").replace("{p}", prefix));
    const targetUsername = rawTarget.replace(/^@/, "").trim();

    let info1, info2;
    try { info1 = await api.getUserInfo(senderID); }
    catch (e) { return message.reply(getLang("error", e.message)); }
    try { info2 = await api.getUserInfoByUsername(targetUsername); }
    catch (e) { return message.reply(getLang("notFound", targetUsername)); }

    const name1  = info1?.full_name || info1?.username || "User";
    const name2  = info2?.full_name || info2?.username  || targetUsername;
    const slapTxt = SLAP_TEXTS[Math.floor(Math.random() * SLAP_TEXTS.length)];

    const pic1url = await getProfilePicUrl(info1);
    const pic2url = await getProfilePicUrl(info2);

    if (!pic1url || !pic2url) {
      return message.reply(getLang("noPhoto", name1, name2, slapTxt));
    }

    try {
      const SIZE = 160;
      const W = 520, H = 260;

      const canvas = createCanvas(W, H);
      const ctx    = canvas.getContext("2d");

      // Background gradient
      const grad = ctx.createLinearGradient(0, 0, W, H);
      grad.addColorStop(0, "#1a1a2e");
      grad.addColorStop(1, "#16213e");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);

      const [av1, av2] = await Promise.all([loadAvatar(pic1url), loadAvatar(pic2url)]);

      // Draw circular avatars
      function drawCircleAvatar(img, x, y, size) {
        ctx.save();
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(img, x, y, size, size);
        ctx.restore();
        // Ring
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
        ctx.strokeStyle = "#ff6b6b";
        ctx.lineWidth   = 4;
        ctx.stroke();
      }

      drawCircleAvatar(av1, 30,  50, SIZE);
      drawCircleAvatar(av2, W - SIZE - 30, 50, SIZE);

      // Slap effect lines
      ctx.strokeStyle = "#ff6b6b";
      ctx.lineWidth   = 6;
      ctx.lineCap     = "round";
      for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.moveTo(220 + i * 8, 80 + i * 15);
        ctx.lineTo(310 - i * 8, 100 + i * 10);
        ctx.stroke();
      }

      // Emoji in the center
      ctx.font      = "60px Arial";
      ctx.textAlign = "center";
      ctx.fillText("👋", W / 2, H / 2 + 20);

      // Names
      ctx.font      = "bold 18px Arial";
      ctx.fillStyle = "#ffffff";
      ctx.textAlign = "center";
      ctx.fillText(name1.slice(0, 14), 30 + SIZE / 2, H - 20);
      ctx.fillText(name2.slice(0, 14), W - SIZE / 2 - 30, H - 20);

      // Title
      ctx.font      = "bold 22px Arial";
      ctx.fillStyle = "#ff6b6b";
      ctx.fillText("SLAP!", W / 2, 40);

      const outPath = path.join(TMP, `slap_${senderID}_${Date.now()}.png`);
      const buf     = canvas.toBuffer("image/png");
      fs.writeFileSync(outPath, buf);

      await api.sendPhotoFromUrl(threadId, `file://${outPath}`, {
        caption: getLang("result", name1, name2, slapTxt),
      }).catch(() => message.reply(getLang("noPhoto", name1, name2, slapTxt)));

      fs.unlinkSync(outPath);
    } catch (e) {
      message.reply(getLang("noPhoto", name1, name2, slapTxt));
    }
  },
};
