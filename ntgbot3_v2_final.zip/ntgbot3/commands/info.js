"use strict";

const { getBalance, getExp } = require("../utils/database");
const { getRole } = require("../utils/permissions");

module.exports = {
  config: {
    name: "info",
    aliases: ["me", "profile"],
    version: "1.0",
    author: "MD RIAD",
    cooldown: 5,
    role: 0,
    description: "View your profile info",
    usage: "info [@username]",
    category: "info",
  },

  onStart: async function ({ api, event, args, getLang }) {
    const { threadId, senderID } = event;
    const target = args[0]?.replace("@", "");
    try {
      const userInfo = target
        ? await api.getUserInfoByUsername(target)
        : await api.getUserInfo(senderID);
      const uid = userInfo.pk || senderID;
      const roleNum = getRole(uid);
      const roleName = roleNum === 4 ? getLang("roleDev") : roleNum === 2 ? getLang("roleAdmin") : roleNum === 3 ? getLang("rolePremium") : getLang("roleUser");
      const msg = [
        getLang("title"),
        getLang("name", userInfo.full_name || "N/A"),
        getLang("username", userInfo.username),
        getLang("followers", (userInfo.follower_count || 0).toLocaleString()),
        getLang("following", (userInfo.following_count || 0).toLocaleString()),
        getLang("posts", (userInfo.media_count || 0).toLocaleString()),
        getLang("verified", userInfo.is_verified ? "✅" : "❌"),
        getLang("private", userInfo.is_private ? "🔒" : "🌐"),
        getLang("botData"),
        getLang("balance", await getBalance(uid)),
        getLang("exp", await getExp(uid)),
        getLang("role", roleName),
      ].join("\n");
      api.sendMessage(msg, threadId);
    } catch (e) {
      api.sendMessage(getLang("error", e.message), threadId);
    }
  },
};
