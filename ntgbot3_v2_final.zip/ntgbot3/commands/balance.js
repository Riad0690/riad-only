"use strict";

const { getBalance } = require("../utils/database");

module.exports = {
  config: {
    name: "balance",
    aliases: ["bal", "coins", "money"],
    version: "1.0",
    author: "MD RIAD",
    cooldown: 3,
    role: 0,
    description: "View your coin balance",
    usage: "balance",
    category: "economy",
  },

  onStart: async function ({ api, event, getLang }) {
    const bal = await getBalance(event.senderID);
    api.sendMessage(getLang("yourBalance", bal), event.threadId);
  },
};
