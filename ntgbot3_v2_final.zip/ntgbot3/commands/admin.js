"use strict";

const { banUserDB, unbanUserDB, addBalance, getAllUsers } = require("../utils/database");
const { reloadCommand } = require("../utils/commandLoader");

module.exports = {
  config: {
    name: "admin",
    aliases: ["adm"],
    version: "1.0",
    author: "MD RIAD",
    cooldown: 2,
    role: 2,
    description: "Bot admin panel",
    usage: "admin <ban|unban|addmoney|removemoney|stats|reload>",
    category: "admin",
  },

  onStart: async function ({ api, event, args, getLang }) {
    const { threadId } = event;
    const sub = args[0]?.toLowerCase();

    if (!sub) return api.sendMessage(getLang("title"), threadId);

    if (sub === "ban") {
      const uid = args[1];
      const hours = parseInt(args[2]) || 24;
      const reason = args.slice(3).join(" ") || "No reason";
      if (!uid) return api.sendMessage(getLang("missingUid"), threadId);
      await banUserDB(uid, hours, reason);
      return api.sendMessage(getLang("banned", uid, hours, reason), threadId);
    }

    if (sub === "unban") {
      if (!args[1]) return api.sendMessage(getLang("missingUid"), threadId);
      await unbanUserDB(args[1]);
      return api.sendMessage(getLang("unbanned", args[1]), threadId);
    }

    if (sub === "addmoney") {
      const uid = args[1];
      const amount = parseInt(args[2]);
      if (!uid) return api.sendMessage(getLang("missingUid"), threadId);
      if (isNaN(amount)) return api.sendMessage(getLang("missingAmount"), threadId);
      await addBalance(uid, amount);
      return api.sendMessage(getLang("addedMoney", amount, uid), threadId);
    }

    if (sub === "removemoney") {
      const uid = args[1];
      const amount = parseInt(args[2]);
      if (!uid) return api.sendMessage(getLang("missingUid"), threadId);
      if (isNaN(amount)) return api.sendMessage(getLang("missingAmount"), threadId);
      await addBalance(uid, -amount);
      return api.sendMessage(getLang("removedMoney", amount, uid), threadId);
    }

    if (sub === "stats") {
      const users = await getAllUsers();
      const uptime = Date.now() - global.NTGBot.startTime;
      const h = Math.floor(uptime / 3600000);
      const m = Math.floor((uptime % 3600000) / 60000);
      return api.sendMessage(getLang("stats",
        users.length,
        users.filter(u => u.banned).length,
        global.NTGBot.commands.size,
        global.NTGBot.events.size,
        h, m,
        global.NTGBot.botID || "NTG"
      ), threadId);
    }

    if (sub === "reload") {
      if (!args[1]) return api.sendMessage(getLang("missingCommand"), threadId);
      try {
        const r = reloadCommand(args[1]);
        return api.sendMessage(getLang("reloaded", r), threadId);
      } catch (e) {
        return api.sendMessage(getLang("reloadError", args[1], e.message), threadId);
      }
    }

    api.sendMessage(getLang("unknownSub"), threadId);
  },
};
