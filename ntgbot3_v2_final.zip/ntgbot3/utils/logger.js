"use strict";

const { createLogger, format, transports } = require("winston");
const path = require("path");
const fs = require("fs");

const logsDir = path.join(__dirname, "../storage/logs");
if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });

// ── ANSI color codes ──────────────────────────────────────────────────────────
const C = {
  reset:   "\x1b[0m",
  bold:    "\x1b[1m",
  dim:     "\x1b[2m",

  black:   "\x1b[30m",
  red:     "\x1b[31m",
  green:   "\x1b[32m",
  yellow:  "\x1b[33m",
  blue:    "\x1b[34m",
  magenta: "\x1b[35m",
  cyan:    "\x1b[36m",
  white:   "\x1b[37m",

  bgRed:    "\x1b[41m",
  bgGreen:  "\x1b[42m",
  bgYellow: "\x1b[43m",
  bgBlue:   "\x1b[44m",
};

// ── Level badge config ────────────────────────────────────────────────────────
const BADGES = {
  error: `${C.bold}${C.bgRed}${C.white} ERROR ${C.reset}`,
  warn:  `${C.bold}${C.bgYellow}${C.black}  WARN ${C.reset}`,
  info:  `${C.bold}${C.bgBlue}${C.white}  INFO ${C.reset}`,
  debug: `${C.bold}${C.black}${C.white} DEBUG ${C.reset}`,
  cmd:   `${C.bold}${C.bgGreen}${C.black}   CMD ${C.reset}`,
  event: `${C.bold}${C.magenta}${C.white} EVENT ${C.reset}`,
  db:    `${C.bold}${C.cyan}${C.black}    DB ${C.reset}`,
  bot:   `${C.bold}${C.green}${C.black}   BOT ${C.reset}`,
};

// ── Timestamp helper ──────────────────────────────────────────────────────────
function ts() {
  return new Date().toLocaleString("en-US", {
    timeZone: (global.NTGBot?.config?.timeZone) || "UTC",
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
    hour12: false,
  }).replace(",", "");
}

// ── Console format (colored) ──────────────────────────────────────────────────
const consoleFormat = format.printf(({ level, message }) => {
  const badge  = BADGES[level] || `${C.dim}[${level.toUpperCase()}]${C.reset}`;
  const time   = `${C.dim}${ts()}${C.reset}`;
  const sep    = `${C.dim}│${C.reset}`;
  return `${time} ${sep} ${badge} ${sep} ${message}`;
});

// ── File format (plain, no ANSI) ──────────────────────────────────────────────
const fileFormat = format.printf(({ level, message }) => {
  // strip any lingering ANSI codes from message
  const clean = message.replace(/\x1b\[[0-9;]*m/g, "");
  return `[${ts()}] [${level.toUpperCase().padEnd(5)}] ${clean}`;
});

// ── Winston logger ────────────────────────────────────────────────────────────
const winstonLogger = createLogger({
  level: "debug",
  transports: [
    new transports.Console({ format: consoleFormat }),
    new transports.File({
      filename: path.join(logsDir, "combined.log"),
      format:   fileFormat,
      maxsize:  5 * 1024 * 1024, // 5 MB rotation
      maxFiles: 5,
    }),
    new transports.File({
      filename: path.join(logsDir, "error.log"),
      level:    "error",
      format:   fileFormat,
      maxsize:  2 * 1024 * 1024,
      maxFiles: 3,
    }),
  ],
});

// ── Public API ────────────────────────────────────────────────────────────────
const logger = {
  info:  (msg) => winstonLogger.log("info",  msg),
  warn:  (msg) => winstonLogger.log("warn",  msg),
  error: (msg) => winstonLogger.log("error", msg),
  debug: (msg) => winstonLogger.log("debug", msg),

  // Semantic helpers
  cmd:   (name, user, status) =>
    winstonLogger.log("cmd",
      `${C.cyan}${name}${C.reset} ← ${C.yellow}@${user}${C.reset} ${status ? `${C.green}✔${C.reset}` : `${C.red}✘${C.reset}`}`),

  event: (name, detail = "") =>
    winstonLogger.log("event",
      `${C.magenta}${name}${C.reset}${detail ? ` ${C.dim}→ ${detail}${C.reset}` : ""}`),

  db:    (msg) => winstonLogger.log("db",    `${C.cyan}${msg}${C.reset}`),

  bot:   (msg) => winstonLogger.log("bot",   `${C.green}${msg}${C.reset}`),

  // Pretty divider line
  divider: (label = "") => {
    const line = "─".repeat(44);
    const text = label
      ? `${C.dim}┌─ ${C.reset}${C.bold}${label}${C.reset} ${C.dim}${"─".repeat(Math.max(0, 40 - label.length))}${C.reset}`
      : `${C.dim}${line}${C.reset}`;
    console.log(text);
  },
};

module.exports = logger;
