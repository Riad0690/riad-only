"use strict";

const fs = require("fs");
const path = require("path");
const logger = require("./logger");

const eventsPath = path.join(__dirname, "../events");

function loadEvents() {
  if (!fs.existsSync(eventsPath)) fs.mkdirSync(eventsPath);
  let loaded = 0;

  for (const file of fs.readdirSync(eventsPath).filter(f => f.endsWith(".js"))) {
    try {
      delete require.cache[require.resolve(path.join(eventsPath, file))];
      const evt = require(path.join(eventsPath, file));
      if (!evt.config?.name) continue;

      if (!evt.onStart || typeof evt.onStart !== "function") {
        logger.warn(`[EVT] ⚠️ ${file}: missing onStart function, skipping`);
        continue;
      }

      global.NTGBot.events.set(evt.config.name, evt);
      loaded++;
      logger.info(`[EVT] ✅ ${evt.config.name}`);
    } catch (e) {
      logger.error(`[EVT] ❌ ${file}: ${e.message}`);
    }
  }

  logger.info(`[EVT] Loaded ${loaded} events`);
}

module.exports = { loadEvents };
