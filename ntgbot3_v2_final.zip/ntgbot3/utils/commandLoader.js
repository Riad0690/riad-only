"use strict";

const fs = require("fs");
const path = require("path");
const logger = require("./logger");

const cmdsPath = path.join(__dirname, "../commands");

function loadCommands() {
  if (!fs.existsSync(cmdsPath)) fs.mkdirSync(cmdsPath);
  let loaded = 0;

  for (const file of fs.readdirSync(cmdsPath).filter(f => f.endsWith(".js"))) {
    try {
      delete require.cache[require.resolve(path.join(cmdsPath, file))];
      const cmd = require(path.join(cmdsPath, file));
      if (!cmd.config?.name) continue;

      // NTG system check - command must have valid config
      if (!cmd.onStart || typeof cmd.onStart !== "function") {
        logger.warn(`[CMD] ⚠️ ${file}: missing onStart function, skipping`);
        continue;
      }

      global.NTGBot.commands.set(cmd.config.name.toLowerCase(), cmd);
      if (cmd.config.aliases) {
        cmd.config.aliases.forEach(a => global.NTGBot.commands.set(a.toLowerCase(), cmd));
      }
      loaded++;
      logger.info(`[CMD] ✅ ${cmd.config.name}`);
    } catch (e) {
      logger.error(`[CMD] ❌ ${file}: ${e.message}`);
    }
  }

  logger.info(`[CMD] Loaded ${loaded} commands`);
}

function reloadCommand(name) {
  const files = fs.readdirSync(cmdsPath).filter(f => f.endsWith(".js"));
  for (const file of files) {
    const fp = path.join(cmdsPath, file);
    delete require.cache[require.resolve(fp)];
    const cmd = require(fp);
    if (cmd.config?.name?.toLowerCase() === name.toLowerCase()) {
      global.NTGBot.commands.set(cmd.config.name.toLowerCase(), cmd);
      if (cmd.config.aliases) {
        cmd.config.aliases.forEach(a => global.NTGBot.commands.set(a.toLowerCase(), cmd));
      }
      return cmd.config.name;
    }
  }
  throw new Error(`Command "${name}" not found`);
}

module.exports = { loadCommands, reloadCommand };
