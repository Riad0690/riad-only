"use strict";

module.exports = {
  config: {
    name: "ready",
    version: "1.0",
    author: "MD RIAD",
    description: "Fires when bot connects successfully",
  },

  onStart: async function ({ bot, getLang }) {
    const logger = require("../utils/logger");
    logger.info(getLang("message", bot.botID || "NTG"));
  },
};
