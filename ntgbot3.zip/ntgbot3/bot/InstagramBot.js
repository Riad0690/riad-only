"use strict";

const fs = require("fs");
const path = require("path");
const { login } = require("@neoaz07/nkxica");
const logger = require("../utils/logger");
const { getLang } = require("../utils/language");
const { loadCommands, reloadCommand } = require("../utils/commandLoader");
const { loadEvents } = require("../utils/eventLoader");
const { initDatabase, isBanned, set, get, getUser } = require("../utils/database");
const { hasRole, getRole } = require("../utils/permissions");
const { populateUtils } = require("../utils/global");

const COOKIES_PATH = path.join(__dirname, "../account.txt");
const spamTracker = new Map();

class NTGBot {
  async buildApi(rawApi) {
    const p = (fn, ...args) => new Promise((res, rej) =>
      fn(...args, (err, r) => err ? rej(err) : res(r))
    );
    return {
      sendMessage:           (text, tid)       => p(rawApi.sendMessage.bind(rawApi), text, tid),
      sendMessageToUser:     (text, uid)       => p(rawApi.sendDirectMessage.bind(rawApi), uid, text),
      replyToMessage:        (tid, text, mid)  => p(rawApi.replyToMessage.bind(rawApi), tid, text, mid),
      sendReaction:          (emoji, mid)      => p(rawApi.sendReaction.bind(rawApi), emoji, mid),
      sendPhotoFromUrl:      (tid, url, opts)  => p(rawApi.sendPhotoFromUrl.bind(rawApi), tid, url, opts || {}),
      sendVideoFromUrl:      (tid, url, opts)  => p(rawApi.sendVideoFromUrl.bind(rawApi), tid, url, opts || {}),
      sendVoiceFromUrl:      (tid, url, opts)  => p(rawApi.sendVoiceFromUrl.bind(rawApi), tid, url, opts || {}),
      unsendMessage:         (mid)             => p(rawApi.unsendMessage.bind(rawApi), mid),
      getUserInfo:           (uid)             => p(rawApi.getUserInfo.bind(rawApi), uid),
      getUserInfoByUsername: (u)               => p(rawApi.getUserInfoByUsername.bind(rawApi), u),
      getThread:             (tid)             => p(rawApi.getThreadInfo.bind(rawApi), tid),
      markAsSeen:            (tid)             => p(rawApi.markAsRead.bind(rawApi), tid, true),
      sendTyping:            (tid)             => p(rawApi.sendTypingIndicator.bind(rawApi), tid),
    };
  }

  isSpamming(senderID) {
    const now = Date.now();
    const win = global.NTGBot.config.spamProtection.timeWindow * 1000;
    if (!spamTracker.has(senderID)) spamTracker.set(senderID, []);
    const ts = spamTracker.get(senderID).filter(t => now - t < win);
    ts.push(now);
    spamTracker.set(senderID, ts);
    return ts.length > global.NTGBot.config.spamProtection.commandThreshold;
  }

  async handleMessage(event, api) {
    const threadId  = event.threadId  || event.threadID  || event.thread_id;
    const senderID  = event.senderID  || event.senderId  || event.sender_id;
    const body      = event.body      || event.message   || event.text || "";
    const messageId = event.messageId || event.messageID || event.message_id;

    if (!body || !senderID || !threadId) return;
    if (String(senderID) === String(global.NTGBot.botID)) return;

    // Banned check
    if (await isBanned(senderID)) {
      const u = await getUser(senderID);
      return api.sendMessage(
        getLang("handler", "userBanned", u.banReason || "No reason", new Date(u.banExpiry).toLocaleString(), senderID),
        threadId
      ).catch(() => {});
    }

    if (global.NTGBot.config.adminOnly?.enable && !hasRole(senderID, 2)) {
      return api.sendMessage(getLang("handler", "onlyAdminBot"), threadId).catch(() => {});
    }

    if (global.NTGBot.config.antiInbox && !event.isGroup) return;

    if (this.isSpamming(senderID)) {
      return api.sendMessage(getLang("handler", "spamDetected"), threadId).catch(() => {});
    }

    // onReply check
    if (event.replyToItemId) {
      const replyData = global.NTGBot.onReply.get(event.replyToItemId);
      if (replyData) {
        const cmd = global.NTGBot.commands.get(replyData.commandName);
        if (cmd?.onReply) {
          try {
            await cmd.onReply({
              api, event: { ...event, threadId, senderID, messageId, args: body.trim().split(/\s+/) },
              args: body.trim().split(/\s+/),
              bot: global.NTGBot,
              replyData,
              getLang: (k, ...a) => getLang(replyData.commandName, k, ...a),
              message: {
                reply: (msg) => api.sendMessage(msg, threadId),
                react: (emoji) => api.sendReaction(emoji, messageId),
              },
            });
          } catch (e) {
            logger.error(`[onReply ERROR] ${replyData.commandName}: ${e.message}`);
          }
          return;
        }
      }
    }

    // onReaction check
    if (event.type === "message_reaction" && event.messageId) {
      const reactionData = global.NTGBot.onReaction.get(event.messageId);
      if (reactionData) {
        const cmd = global.NTGBot.commands.get(reactionData.commandName);
        if (cmd?.onReaction) {
          try {
            await cmd.onReaction({ api, event, bot: global.NTGBot, reactionData, getLang: (k, ...a) => getLang(reactionData.commandName, k, ...a) });
          } catch (e) {
            logger.error(`[onReaction ERROR] ${reactionData.commandName}: ${e.message}`);
          }
          return;
        }
      }
    }

    // onChat - runs on every message for commands that have it
    for (const [, cmd] of global.NTGBot.commands) {
      if (cmd.onChat) {
        try {
          await cmd.onChat({
            api,
            event: { ...event, threadId, senderID, messageId, body },
            args: body.trim().split(/\s+/),
            bot: global.NTGBot,
            getLang: (k, ...a) => getLang(cmd.config.name, k, ...a),
            message: {
              reply: (msg) => api.sendMessage(msg, threadId),
              react: (emoji) => api.sendReaction(emoji, messageId),
            },
          });
        } catch (e) {
          // silent fail for onChat
        }
      }
    }

    // Command parser
    const prefix = global.NTGBot.config.prefix;
    const role = getRole(senderID);
    const hasPrefix = body.startsWith(prefix);
    const noPrefix = global.NTGBot.config.noPrefix && role >= 2;
    if (!hasPrefix && !noPrefix) return;

    const args = (hasPrefix ? body.slice(prefix.length) : body).trim().split(/\s+/);
    const commandName = args.shift().toLowerCase();
    if (!commandName) return;

    const cmd = global.NTGBot.commands.get(commandName);
    if (!cmd) return;

    // Role check
    if (!hasRole(senderID, cmd.config.role || 0)) {
      return api.sendMessage(getLang("handler", "noPermission", commandName), threadId).catch(() => {});
    }

    // Cooldown check
    const cdKey = `cd:${senderID}:${cmd.config.name}`;
    const lastUsed = await get(cdKey) || 0;
    const cooldown = (cmd.config.cooldown || 0) * 1000;
    if (Date.now() - lastUsed < cooldown) {
      const rem = Math.ceil((cooldown - (Date.now() - lastUsed)) / 1000);
      return api.sendMessage(getLang("handler", "waitingCooldown", rem, cmd.config.name), threadId).catch(() => {});
    }
    if (cooldown > 0) await set(cdKey, Date.now());

    // Typing indicator
    if (global.NTGBot.config.typingIndicator?.enable) {
      try { await api.sendTyping(threadId); } catch {}
      await new Promise(r => setTimeout(r, global.NTGBot.config.typingIndicator.duration || 1500));
    }

    // Normalized event
    const normalizedEvent = { ...event, threadId, senderID, messageId, args, body };

    // Build context
    const ctx = {
      api,
      event:       normalizedEvent,
      args,
      bot:         global.NTGBot,
      getLang:     (k, ...a) => getLang(cmd.config.name, k, ...a),
      message: {
        reply:     (msg) => api.sendMessage(msg, threadId),
        react:     (emoji) => api.sendReaction(emoji, messageId),
        unsend:    (mid) => api.unsendMessage(mid),
      },
      // GoatBot style data access
      usersData:   global.NTGBot.utils,
      threadsData: global.NTGBot.utils,
    };

    try {
      await api.sendReaction("⏳", messageId).catch(() => {});
      await cmd.onStart(ctx);
      await api.sendReaction("✅", messageId).catch(() => {});
    } catch (e) {
      logger.error(`[CMD ERROR] ${cmd.config.name}: ${e.message}`);
      await api.sendReaction("❌", messageId).catch(() => {});
      api.sendMessage(getLang("handler", "errorOccurred", cmd.config.name, e.message), threadId).catch(() => {});
    }
  }

  async fireEvent(name, payload, api) {
    const evt = global.NTGBot.events.get(name);
    if (!evt?.onStart) return;
    try {
      await evt.onStart({
        api,
        event: payload,
        bot: global.NTGBot,
        getLang: (k, ...a) => getLang(name, k, ...a),
      });
    } catch (e) {
      logger.error(`[EVT ERROR] ${name}: ${e.message}`);
    }
  }

  async loginBot() {
    if (!fs.existsSync(COOKIES_PATH)) {
      logger.error(getLang("login", "notFoundAccount"));
      process.exit(1);
    }
    logger.info(getLang("login", "loggingIn"));
    const cookies = fs.readFileSync(COOKIES_PATH, "utf-8");

    return new Promise((resolve, reject) => {
      login(cookies, { logLevel: "silent" }, (err, rawApi) => {
        if (err) return reject(err);
        const uid = rawApi.getCurrentUserID();
        global.NTGBot.botID = typeof uid === "object" ? (uid.pk || uid.id || String(uid)) : String(uid);
        logger.info(getLang("login", "loginSuccess", global.NTGBot.botID));
        resolve(rawApi);
      });
    });
  }

  async startListening(rawApi) {
    const api = await this.buildApi(rawApi);

    await this.fireEvent("ready", { botID: global.NTGBot.botID }, api);
    logger.info(getLang("login", "startListening"));

    rawApi.listen((err, event) => {
      if (err) return logger.error("Listen error: " + err.message);
      try {
        switch (event.type) {
          case "message":          this.handleMessage(event, api); break;
          case "message_reaction": this.handleMessage(event, api); break;
          case "gc_join":          this.fireEvent("gc_join", event, api); break;
          case "gc_leave":         this.fireEvent("gc_leave", event, api); break;
          case "bot_added":        this.fireEvent("bot_added", event, api); break;
        }
      } catch (e) {
        logger.error("Handler error: " + e.message);
      }
    });

    if (global.NTGBot.config.restartListenMqtt?.enable) {
      setInterval(() => {
        logger.info(getLang("login", "restartMqtt"));
        try { rawApi.stopListening(); } catch {}
        rawApi.listen((err) => { if (err) logger.error("Restart error: " + err.message); });
      }, global.NTGBot.config.restartListenMqtt.timeRestart || 3600000);
    }
  }

  async boot() {
    // Init utils into global
    populateUtils();

    // Init database
    await initDatabase();

    // Load commands and events into global
    loadCommands();
    loadEvents();

    // Login and start
    const rawApi = await this.loginBot();
    await this.startListening(rawApi);
  }
}

module.exports = NTGBot;
