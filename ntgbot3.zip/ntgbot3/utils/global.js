"use strict";

const config = require("../config");

function initGlobal() {
  global.NTGBot = {
    // Core
    config,
    commands:  new Map(),
    events:    new Map(),
    onReply:   new Map(),
    onReaction: new Map(),

    // Bot info
    botID:     null,
    username:  null,
    startTime: Date.now(),
    version:   "1.0.0",
    author:    "MD RIAD",
    authorUID: "51704856285",

    // Language
    language:  {},

    // Utils (populated after init)
    utils: {
      getLang:     null,
      getRole:     null,
      hasRole:     null,
      getBalance:  null,
      addBalance:  null,
      setBalance:  null,
      getExp:      null,
      addExp:      null,
      getUser:     null,
      isBanned:    null,
      banUser:     null,
      unbanUser:   null,
      set:         null,
      get:         null,
      del:         null,
      logger:      null,
    },
  };
}

// NTG system check - every command must pass this
// Commands without valid NTG signature will not run
function ntgCheck(cmd) {
  if (!cmd) return false;
  if (!cmd.config?.name) return false;
  if (!cmd.onStart || typeof cmd.onStart !== "function") return false;
  return true;
}

// Populate global utils after all modules load
function populateUtils() {
  const { getLang }                                        = require("../utils/language");
  const { getRole, hasRole }                               = require("../utils/permissions");
  const { getBalance, addBalance, setBalance,
          getExp, addExp, getUser,
          isBanned, banUserDB, unbanUserDB,
          set, get, del }                                  = require("../utils/database");
  const logger                                             = require("../utils/logger");

  global.NTGBot.utils = {
    getLang, getRole, hasRole,
    getBalance, addBalance, setBalance,
    getExp, addExp, getUser,
    isBanned, banUser: banUserDB, unbanUser: unbanUserDB,
    set, get, del,
    logger,
  };
}

module.exports = { initGlobal, ntgCheck, populateUtils };
