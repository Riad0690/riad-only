"use strict";

function getRole(userID) {
  const id = String(userID);
  const { devUsers, adminBot, premiumUsers } = global.NTGBot.config;
  if (devUsers.includes(id)) return 4;
  if (adminBot.includes(id)) return 2;
  if ((premiumUsers || []).includes(id)) return 3;
  return 0;
}

function hasRole(userID, required) {
  const r = getRole(userID);
  if (r === 4) return true;
  return r >= required;
}

module.exports = { getRole, hasRole };
