"use strict";

const fs   = require("fs");
const path = require("path");
const { login }                          = require("@neoaz07/nkxica");
const logger                             = require("../utils/logger");
const { getLang }                        = require("../utils/language");
const { loadCommands, reloadCommand }    = require("../utils/commandLoader");
const { loadEvents }                     = require("../utils/eventLoader");
const { initDatabase, isBanned, set, get, getUser } = require("../utils/database");
const { hasRole, getRole, getRoleRequired } = require("../utils/permissions");
const { populateUtils }                  = require("../utils/global");

const COOKIES_PATH = path.join(__dirname, "../account.txt");
const spamTracker  = new Map();

// ── Shorthand helpers ─────────────────────────────────────────────────────────
function cfg()          { return global.NTGBot.config; }
function logCfg()       { return cfg().logEvents || {}; }
function hideCfg()      { return cfg().hideNotiMessage || {}; }
function shouldLog(key) { return !logCfg().disableAll && logCfg()[key] !== false; }
function shouldHide(key){ return hideCfg()[key] === true; }

// ─────────────────────────────────────────────────────────────────────────────
class NTGBot {

  // ── Promisify raw API methods ─────────────────────────────────────────────
  async buildApi(rawApi) {
    const p = (fn, ...args) => new Promise((res, rej) =>
      fn(...args, (err, r) => err ? rej(err) : res(r))
    );
    return {
      sendMessage:           (text, tid)      => p(rawApi.sendMessage.bind(rawApi), text, tid),
      sendMessageToUser:     (text, uid)      => p(rawApi.sendDirectMessage.bind(rawApi), uid, text),
      replyToMessage:        (tid, text, mid) => p(rawApi.replyToMessage.bind(rawApi), tid, text, mid),
      sendReaction:          (emoji, mid)     => p(rawApi.sendReaction.bind(rawApi), emoji, mid),
      sendPhotoFromUrl:      (tid, url, o)    => p(rawApi.sendPhotoFromUrl.bind(rawApi), tid, url, o || {}),
      sendVideoFromUrl:      (tid, url, o)    => p(rawApi.sendVideoFromUrl.bind(rawApi), tid, url, o || {}),
      sendVoiceFromUrl:      (tid, url, o)    => p(rawApi.sendVoiceFromUrl.bind(rawApi), tid, url, o || {}),
      unsendMessage:         (mid)            => p(rawApi.unsendMessage.bind(rawApi), mid),
      getUserInfo:           (uid)            => p(rawApi.getUserInfo.bind(rawApi), uid),
      getUserInfoByUsername: (u)              => p(rawApi.getUserInfoByUsername.bind(rawApi), u),
      getThread:             (tid)            => p(rawApi.getThreadInfo.bind(rawApi), tid),
      markAsSeen:            (tid)            => p(rawApi.markAsRead.bind(rawApi), tid, true),
      sendTyping:            (tid)            => p(rawApi.sendTypingIndicator.bind(rawApi), tid),
    };
  }

  // ── Spam detection ────────────────────────────────────────────────────────
  isSpamming(senderID) {
    if (!cfg().spamProtection?.enable) return false;
    const now = Date.now();
    const win = cfg().spamProtection.timeWindow * 1000;
    if (!spamTracker.has(senderID)) spamTracker.set(senderID, []);
    const ts = spamTracker.get(senderID).filter(t => now - t < win);
    ts.push(now);
    spamTracker.set(senderID, ts);
    return ts.length > cfg().spamProtection.commandThreshold;
  }

  // ── Main message handler ──────────────────────────────────────────────────
  async handleMessage(event, api) {
    const threadId  = event.threadId  || event.threadID  || event.thread_id;
    const senderID  = event.senderID  || event.senderId  || event.sender_id;
    const body      = event.body      || event.message   || event.text || "";
    const messageId = event.messageId || event.messageID || event.message_id;

    if (!body || !senderID || !threadId) return;
    if (String(senderID) === String(global.NTGBot.botID)) return;

    // ── Stats ──────────────────────────────────────────────────────────────
    global.NTGBot.stats.totalMessages++;

    // ── Log incoming message ───────────────────────────────────────────────
    if (shouldLog("message")) {
      logger.message(senderID, threadId, body, !!event.isGroup);
    }

    // ── Banned check ───────────────────────────────────────────────────────
    if (await isBanned(senderID)) {
      if (!shouldHide("userBanned")) {
        const u = await getUser(senderID);
        api.sendMessage(
          getLang("handler", "userBanned", u.banReason || "No reason", new Date(u.banExpiry).toLocaleString(), senderID),
          threadId
        ).catch(() => {});
      }
      return;
    }

    // ── Admin-only mode ────────────────────────────────────────────────────
    if (cfg().adminOnly?.enable && !hasRole(senderID, 2)) {
      if (!cfg().adminOnly.hideNotiMessage) {
        api.sendMessage(getLang("handler", "onlyAdminBot"), threadId).catch(() => {});
      }
      return;
    }

    // ── Whitelist mode ─────────────────────────────────────────────────────
    if (cfg().whiteListMode?.enable) {
      const wl = (cfg().whiteListMode.whiteListIds || []).map(String);
      if (!wl.includes(String(senderID))) return;
    }

    // ── Anti-inbox (group only) ────────────────────────────────────────────
    if (cfg().antiInbox && !event.isGroup) return;

    // ── Spam check ─────────────────────────────────────────────────────────
    if (this.isSpamming(senderID)) {
      if (shouldLog("spam")) logger.warn(`Spam detected | UID: ${senderID} | TID: ${threadId}`);
      if (!shouldHide("spamDetected")) {
        api.sendMessage(getLang("handler", "spamDetected"), threadId).catch(() => {});
      }
      return;
    }

    // ── onReply handler ────────────────────────────────────────────────────
    if (event.replyToItemId) {
      const replyData = global.NTGBot.onReply.get(event.replyToItemId);
      if (replyData) {
        const cmd = global.NTGBot.commands.get(replyData.commandName);
        if (cmd?.onReply) {
          try {
            await cmd.onReply({
              api,
              event:     { ...event, threadId, senderID, messageId, args: body.trim().split(/\s+/) },
              args:      body.trim().split(/\s+/),
              bot:       global.NTGBot,
              replyData,
              getLang:   (k, ...a) => getLang(replyData.commandName, k, ...a),
              message: {
                reply:   (msg) => api.sendMessage(msg, threadId),
                react:   (emoji) => api.sendReaction(emoji, messageId),
              },
            });
          } catch (e) {
            global.NTGBot.stats.totalErrors++;
            if (shouldLog("commandError")) logger.command(replyData.commandName, senderID, threadId, false, `[onReply] ${e.message}`);
          }
          return;
        }
      }
    }

    // ── onReaction handler ─────────────────────────────────────────────────
    if (event.type === "message_reaction" && event.messageId) {
      if (shouldLog("message_reaction")) {
        logger.event("reaction", `UID: ${senderID} | TID: ${threadId} | MID: ${event.messageId}`);
      }
      const reactionData = global.NTGBot.onReaction.get(event.messageId);
      if (reactionData) {
        const cmd = global.NTGBot.commands.get(reactionData.commandName);
        if (cmd?.onReaction) {
          try {
            await cmd.onReaction({
              api, event, bot: global.NTGBot, reactionData,
              getLang: (k, ...a) => getLang(reactionData.commandName, k, ...a),
            });
          } catch (e) {
            global.NTGBot.stats.totalErrors++;
            if (shouldLog("eventError")) logger.command(reactionData.commandName, senderID, threadId, false, `[onReaction] ${e.message}`);
          }
          return;
        }
      }
    }

    // ── onChat (runs for every message, all commands) ──────────────────────
    for (const [, cmd] of global.NTGBot.commands) {
      if (cmd.onChat) {
        try {
          await cmd.onChat({
            api,
            event:   { ...event, threadId, senderID, messageId, body },
            args:    body.trim().split(/\s+/),
            bot:     global.NTGBot,
            getLang: (k, ...a) => getLang(cmd.config.name, k, ...a),
            message: {
              reply:   (msg) => api.sendMessage(msg, threadId),
              react:   (emoji) => api.sendReaction(emoji, messageId),
            },
          });
        } catch { /* silent fail for onChat */ }
      }
    }

    // ── Command parser ─────────────────────────────────────────────────────
    const prefix    = cfg().prefix;
    const role      = getRole(senderID);
    const hasPrefix = body.startsWith(prefix);
    const noPrefixAllowed = cfg().noPrefix && role >= 2;

    if (!hasPrefix && !noPrefixAllowed) return;

    const args        = (hasPrefix ? body.slice(prefix.length) : body).trim().split(/\s+/);
    const commandName = (args.shift() || "").toLowerCase();
    if (!commandName) return;

    // When running in noPrefix mode (no leading prefix), only treat the
    // message as a command if the first word is an actual registered command
    // name/alias — otherwise normal chat messages from admins would get
    // swallowed and silently dropped.
    if (!hasPrefix && noPrefixAllowed && !global.NTGBot.commands.has(commandName)) {
      return;
    }

    const cmd = global.NTGBot.commands.get(commandName)
             || global.NTGBot.commands.get(
                  [...global.NTGBot.commands.entries()]
                    .find(([, c]) => c.config?.aliases?.includes(commandName))?.[0]
                );

    if (!cmd) {
      if (!shouldHide("commandNotFound")) {
        api.sendMessage(getLang("handler", "commandNotFound", commandName, prefix), threadId).catch(() => {});
      }
      return;
    }

    // ── Role / permission check ────────────────────────────────────────────
    const requiredRole = cmd.config.role || 0;
    if (!hasRole(senderID, requiredRole)) {
      if (!shouldHide("noPermission")) {
        api.sendMessage(
          getLang("handler", "noPermission", commandName, getRoleRequired(requiredRole)),
          threadId
        ).catch(() => {});
      }
      return;
    }

    // ── Cooldown check ─────────────────────────────────────────────────────
    const cdKey   = `cd:${senderID}:${cmd.config.name}`;
    const lastUsed = await get(cdKey) || 0;
    const cooldown = (cmd.config.cooldown || 0) * 1000;
    if (Date.now() - lastUsed < cooldown) {
      const rem = Math.ceil((cooldown - (Date.now() - lastUsed)) / 1000);
      if (!shouldHide("waitingCooldown")) {
        api.sendMessage(getLang("handler", "waitingCooldown", rem, cmd.config.name), threadId).catch(() => {});
      }
      return;
    }
    if (cooldown > 0) await set(cdKey, Date.now());

    // ── Typing indicator ───────────────────────────────────────────────────
    if (cfg().typingIndicator?.enable) {
      try { await api.sendTyping(threadId); } catch {}
      await new Promise(r => setTimeout(r, cfg().typingIndicator.duration || 1500));
    }

    // ── Build context ──────────────────────────────────────────────────────
    const normalizedEvent = { ...event, threadId, senderID, messageId, args, body };
    const ctx = {
      api,
      event:       normalizedEvent,
      args,
      bot:         global.NTGBot,
      getLang:     (k, ...a) => getLang(cmd.config.name, k, ...a),
      message: {
        reply:     (msg)   => api.sendMessage(msg, threadId),
        react:     (emoji) => api.sendReaction(emoji, messageId),
        unsend:    (mid)   => api.unsendMessage(mid),
      },
      usersData:   global.NTGBot.utils,
      threadsData: global.NTGBot.utils,
    };

    // ── Execute command ────────────────────────────────────────────────────
    try {
      await api.sendReaction("⏳", messageId).catch(() => {});
      await cmd.onStart(ctx);
      await api.sendReaction("✅", messageId).catch(() => {});

      global.NTGBot.stats.totalCommands++;
      if (shouldLog("message")) logger.command(cmd.config.name, senderID, threadId, true);

    } catch (e) {
      global.NTGBot.stats.totalErrors++;
      await api.sendReaction("❌", messageId).catch(() => {});

      if (shouldLog("commandError")) logger.command(cmd.config.name, senderID, threadId, false, e.message);

      api.sendMessage(
        getLang("handler", "errorOccurred", cmd.config.name, e.message),
        threadId
      ).catch(() => {});

      // Notify devs on error if enabled
      if (cfg().notiWhenError?.enable) {
        const errMsg =
          `❌ Command Error!\n` +
          `${"─".repeat(28)}\n` +
          `📦 Command : ${cmd.config.name}\n` +
          `👤 User    : @${senderID}\n` +
          `💬 Input   : ${body.slice(0, 100)}\n` +
          `❗ Error   : ${e.message}`;

        for (const uid of (cfg().devUsers || [])) {
          api.sendMessageToUser(errMsg, uid).catch(() => {});
        }
      }
    }
  }

  // ── Event dispatcher ──────────────────────────────────────────────────────
  async fireEvent(name, payload, api) {
    const evt = global.NTGBot.events.get(name);
    if (!evt?.onStart) return;
    try {
      await evt.onStart({
        api,
        event:   payload,
        bot:     global.NTGBot,
        getLang: (k, ...a) => getLang(name, k, ...a),
      });
    } catch (e) {
      global.NTGBot.stats.totalErrors++;
      if (shouldLog("eventError")) {
        const tid = payload?.threadId || payload?.thread_id || "N/A";
        const uid = payload?.userId   || payload?.user_id   || payload?.senderID || "N/A";
        logger.error(`[EVT] ${name} | UID: ${uid} | TID: ${tid} → ${e.message}`);
      }
    }
  }

  // ── Login ─────────────────────────────────────────────────────────────────
  async loginBot() {
    if (!fs.existsSync(COOKIES_PATH)) {
      logger.error(getLang("login", "notFoundAccount"));
      process.exit(1);
    }
    logger.info(getLang("login", "loggingIn"));
    const cookies = fs.readFileSync(COOKIES_PATH, "utf-8");

    return new Promise((resolve, reject) => {
      login(cookies, { logLevel: "silent" }, (err, rawApi) => {
        if (err) return reject(err);
        const uid = rawApi.getCurrentUserID();
        global.NTGBot.botID = typeof uid === "object"
          ? (uid.pk || uid.id || String(uid))
          : String(uid);
        logger.info(getLang("login", "loginSuccess", global.NTGBot.botID));
        resolve(rawApi);
      });
    });
  }

  // ── Start listening ───────────────────────────────────────────────────────
  async startListening(rawApi) {
    const api = await this.buildApi(rawApi);

    await this.fireEvent("ready", { botID: global.NTGBot.botID }, api);
    logger.info(getLang("login", "startListening"));

    rawApi.listen((err, event) => {
      if (err) return logger.error("Listen error: " + err.message);
      try {
        switch (event.type) {
          case "message":          this.handleMessage(event, api); break;
          case "message_reaction": this.handleMessage(event, api); break;
          case "gc_join": {
            const tid = event.threadId || event.thread_id || "N/A";
            const uid = event.userId   || event.user_id   || "N/A";
            if (shouldLog("gc_join")) logger.event("gc_join", `UID: ${uid} | TID: ${tid}`);
            this.fireEvent("gc_join", event, api);
            break;
          }
          case "gc_leave": {
            const tid = event.threadId || event.thread_id || "N/A";
            const uid = event.userId   || event.user_id   || "N/A";
            if (shouldLog("gc_leave")) logger.event("gc_leave", `UID: ${uid} | TID: ${tid}`);
            this.fireEvent("gc_leave", event, api);
            break;
          }
          case "bot_added": {
            const tid = event.threadId || event.thread_id || "N/A";
            if (shouldLog("bot_added")) logger.event("bot_added", `TID: ${tid}`);
            this.fireEvent("bot_added", event, api);
            break;
          }
        }
      } catch (e) {
        logger.error("Handler error: " + e.message);
      }
    });

    // ── MQTT auto-restart ─────────────────────────────────────────────────
    const mqttCfg = cfg().restartListenMqtt;
    if (mqttCfg?.enable) {
      setInterval(async () => {
        if (mqttCfg.logNoti) logger.info(getLang("login", "restartMqtt"));
        try { rawApi.stopListening(); } catch {}
        await new Promise(r => setTimeout(r, mqttCfg.delayAfterStop || 2000));
        rawApi.listen((err) => {
          if (err) logger.error("MQTT restart error: " + err.message);
          else if (mqttCfg.logNoti) logger.info(getLang("login", "restartMqttSuccess"));
        });
      }, mqttCfg.timeRestart || 3600000);
    }

    // ── Auto restart bot ──────────────────────────────────────────────────
    const restartCfg = cfg().autoRestart;
    if (restartCfg?.enable && restartCfg.time) {
      setTimeout(() => {
        logger.warn("Auto restart triggered. Shutting down...");
        process.exit(0);
      }, restartCfg.time);
    }
  }

  // ── Boot sequence ─────────────────────────────────────────────────────────
  async boot() {
    populateUtils();
    await initDatabase();
    loadCommands();
    loadEvents();
    const rawApi = await this.loginBot();
    await this.startListening(rawApi);
  }
}

module.exports = NTGBot;
