/**
 * ╔══════════════════════════════════════════════════════════╗
 * ║          NTG BOT — Event Template                       ║
 * ║          Platform  : Instagram                          ║
 * ║          Author    : MD RIAD                            ║
 * ║                                                         ║
 * ║  HOW TO USE:                                            ║
 * ║  1. Copy this file and rename it (remove ".eg")         ║
 * ║     e.g.  myevent.eg.js  →  myevent.js                 ║
 * ║  2. Set config.name to one of the supported event types ║
 * ║  3. Drop it in the events/ folder — auto-loaded         ║
 * ║                                                         ║
 * ║  Files ending in ".eg.js" are IGNORED by the loader.   ║
 * ╚══════════════════════════════════════════════════════════╝
 *
 * SUPPORTED EVENT TYPES (set as config.name):
 *   ready      — fires once when bot successfully connects
 *   gc_join    — someone joins the group
 *   gc_leave   — someone leaves the group
 *   bot_added  — bot is added to a new group
 *
 * AVAILABLE in onStart:
 *   api     — Instagram API methods
 *   event   — the raw event payload (varies by type)
 *   bot     — global.NTGBot
 *   getLang(key, ...params) — from langs below
 *
 * API METHODS:
 *   api.sendMessage(text, threadId)
 *   api.sendMessageToUser(text, userId)
 *   api.sendPhotoFromUrl(threadId, url, opts)
 *   api.getUserInfo(userId)
 *   api.getUserInfoByUsername(username)
 *   api.getThread(threadId)
 */

"use strict";

module.exports = {

  // ── Config ────────────────────────────────────────────────────────────────
  config: {
    name:        "gc_join",   // event type this file handles (see list above)
    version:     "1.0",
    author:      "Your Name",
    description: "Fires when someone joins the group",
    category:    "events",
  },

  // ── Language strings ──────────────────────────────────────────────────────
  langs: {
    en: {
      welcome: "👋 Welcome to the group, %1!\nType !help to see what I can do.",
    },
  },

  // ── onStart — runs when the event fires ──────────────────────────────────
  onStart: async function ({ api, event, bot, getLang }) {
    const threadId = event.threadId || event.thread_id;
    const userId   = event.userId   || event.user_id;

    if (!threadId) return;

    // Try to get the user's name
    let name = "there";
    try {
      const info = await api.getUserInfo(userId);
      name = info?.full_name || info?.username || name;
    } catch {}

    api.sendMessage(getLang("welcome", name), threadId).catch(() => {});
  },
};
