"use strict";

module.exports = {
  config: {
    name: "gc_join",
    version: "1.0",
    author: "MD RIAD",
    description: "Welcome new members to the group",
  },

  onStart: async function ({ api, event, getLang }) {
    const { threadId, userId } = event;
    try {
      const u = await api.getUserInfo(userId);
      const name = u?.full_name || u?.username || "someone";
      await api.sendMessage(getLang("joined", name), threadId);
    } catch {
      await api.sendMessage(getLang("joinedGeneric"), threadId);
    }
  },
};
