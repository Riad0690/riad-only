"use strict";

module.exports = {
  config: {
    name:        "ready",
    version:     "2.0",
    author:      "MD RIAD",
    description: "Fires when bot connects. Sends start notification to devUsers & adminBot.",
  },

  onStart: async function ({ api, bot }) {
    const logger = require("../utils/logger");
    const { getRoleName } = require("../utils/permissions");
    const cfg = bot.config;

    // ── Console banner ─────────────────────────────────────────────────────
    logger.divider("BOT READY");
    logger.bot(`NTG Bot v${bot.version} is online`);
    logger.bot(`Bot UID   : ${bot.botID || "unknown"}`);
    logger.bot(`Commands  : ${bot.commands.size}`);
    logger.bot(`Events    : ${bot.events.size}`);
    logger.bot(`Prefix    : ${cfg.prefix}`);
    logger.bot(`Language  : ${cfg.language}`);
    logger.bot(`Database  : ${cfg.database?.type || "json"}`);
    logger.divider();

    // ── DM notification ────────────────────────────────────────────────────
    if (!cfg.notiWhenStart?.enable) return;

    const uptime   = new Date().toLocaleString("en-US", { timeZone: cfg.timeZone || "UTC" });
    const cmdList  = [...bot.commands.keys()].join(", ") || "none";

    const msg =
      `🚀 NTG Bot Started!\n` +
      `${"─".repeat(30)}\n` +
      `🤖 Bot UID   : ${bot.botID || "N/A"}\n` +
      `📦 Version   : v${bot.version}\n` +
      `⚡ Commands  : ${bot.commands.size} loaded\n` +
      `📂 Cmds      : ${cmdList}\n` +
      `🌐 Language  : ${cfg.language}\n` +
      `💾 Database  : ${cfg.database?.type || "json"}\n` +
      `🕐 Time      : ${uptime}\n` +
      `${"─".repeat(30)}\n` +
      `✅ Bot is now listening for messages.`;

    // collect unique recipient IDs (dev + admin, no duplicates)
    const recipients = [
      ...(cfg.devUsers   || []),
      ...(cfg.adminBot   || []),
    ].filter((id, i, arr) => arr.indexOf(id) === i);

    for (const uid of recipients) {
      try {
        await api.sendMessageToUser(msg, uid);
        logger.info(`Start notification sent → UID ${uid} (${getRoleName(global.NTGBot.utils.getRole(uid))})`);
      } catch (e) {
        logger.warn(`Could not send start notification to UID ${uid}: ${e.message}`);
      }
    }
  },
};
