"use strict";

module.exports = {
  config: {
    name: "gc_leave",
    version: "1.0",
    author: "MD RIAD",
    description: "Farewell message when someone leaves",
  },

  onStart: async function ({ api, event, getLang }) {
    const { threadId, leftUserId } = event;
    try {
      const u = await api.getUserInfo(leftUserId);
      const name = u?.full_name || u?.username || "Someone";
      await api.sendMessage(getLang("left", name), threadId);
    } catch {
      await api.sendMessage(getLang("leftGeneric"), threadId);
    }
  },
};
