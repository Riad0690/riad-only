"use strict";

const fs = require("fs");
const path = require("path");

const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, "default.json"), "utf-8"));

if (process.env.PREFIX) cfg.prefix = process.env.PREFIX;
if (process.env.MONGODB_URI) cfg.database.mongodbUri = process.env.MONGODB_URI;

module.exports = cfg;
