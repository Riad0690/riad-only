"use strict";

const { initGlobal } = require("./utils/global");
const { initLanguage, getLang } = require("./utils/language");
const NTGBot = require("./bot/InstagramBot");
const logger = require("./utils/logger");

// Step 1: Init global.NTGBot object first
initGlobal();

// Step 2: Init language
initLanguage();

console.log(`
╔══════════════════════════════════════════╗
║                                          ║
║    ███╗   ██╗████████╗ ██████╗           ║
║    ████╗  ██║╚══██╔══╝██╔════╝           ║
║    ██╔██╗ ██║   ██║   ██║  ███╗          ║
║    ██║╚██╗██║   ██║   ██║   ██║          ║
║    ██║ ╚████║   ██║   ╚██████╔╝          ║
║    ╚═╝  ╚═══╝   ╚═╝    ╚═════╝           ║
║                                          ║
║    Instagram Bot  |  by MD RIAD          ║
║    UID: 51704856285                      ║
║    Prefix: ${global.NTGBot.config.prefix.padEnd(30)}║
╚══════════════════════════════════════════╝
`);

logger.info(getLang("index", "starting"));

const bot = new NTGBot();
bot.boot().catch(err => {
  logger.error("Fatal: " + err.message);
  process.exit(1);
});

process.on("SIGINT", () => {
  logger.info("Shutting down NTG Bot...");
  process.exit(0);
});

process.on("uncaughtException", err => logger.error("Uncaught: " + err.message));
process.on("unhandledRejection", err => logger.error("Rejection: " + (err?.message || err)));
