"use strict";

const fs = require("fs");
const path = require("path");

const dataDir = path.join(__dirname, "../storage/data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

let mongoose;
let isMongoConnected = false;
let UserModel, KVModel;

const DB_FILE = path.join(dataDir, "bot.json");
let jsonDB = { users: {}, kv: {} };

function loadJSON() {
  if (fs.existsSync(DB_FILE)) {
    jsonDB = JSON.parse(fs.readFileSync(DB_FILE, "utf-8"));
    jsonDB.users = jsonDB.users || {};
    jsonDB.kv = jsonDB.kv || {};
  }
}

function saveJSON() {
  fs.writeFileSync(DB_FILE, JSON.stringify(jsonDB, null, 2));
}

function initMongoModels() {
  const { Schema } = mongoose;
  const userSchema = new Schema({
    uid: { type: String, required: true, unique: true },
    balance: { type: Number, default: 0 },
    exp: { type: Number, default: 0 },
    banned: { type: Boolean, default: false },
    banExpiry: { type: Number, default: 0 },
    banReason: { type: String, default: "" },
    createdAt: { type: Number, default: Date.now },
  });
  const kvSchema = new Schema({
    key: { type: String, required: true, unique: true },
    value: mongoose.Schema.Types.Mixed,
  });
  UserModel = mongoose.models.User || mongoose.model("User", userSchema);
  KVModel = mongoose.models.KV || mongoose.model("KV", kvSchema);
}

async function initDatabase() {
  const logger = require("./logger");
  const { getLang } = require("./language");
  const uri = global.NTGBot.config.database?.mongodbUri;

  if (uri && uri.trim() !== "") {
    try {
      mongoose = require("mongoose");
      logger.info(getLang("database", "connectingMongoDB"));
      await mongoose.connect(uri);
      initMongoModels();
      isMongoConnected = true;
      logger.info(getLang("database", "connectMongoDBSuccess"));
    } catch (e) {
      logger.error(getLang("database", "connectMongoDBError", e.message));
      logger.warn("Falling back to JSON database...");
      loadJSON();
      setInterval(saveJSON, (global.NTGBot.config.database?.saveIntervalMinutes || 1) * 60000);
    }
  } else {
    logger.info(getLang("database", "connectingJSON"));
    loadJSON();
    setInterval(saveJSON, (global.NTGBot.config.database?.saveIntervalMinutes || 1) * 60000);
  }

  logger.info(getLang("database", "initSuccess"));
}

async function ensureUser(uid) {
  uid = String(uid);
  if (isMongoConnected) {
    let u = await UserModel.findOne({ uid });
    if (!u) u = await UserModel.create({ uid });
    return u;
  }
  if (!jsonDB.users[uid]) {
    jsonDB.users[uid] = { uid, balance: 0, exp: 0, banned: false, banExpiry: 0, banReason: "", createdAt: Date.now() };
  }
  return jsonDB.users[uid];
}

async function getUser(uid) { return await ensureUser(uid); }
async function getAllUsers() {
  if (isMongoConnected) return await UserModel.find({});
  return Object.values(jsonDB.users);
}

async function getBalance(uid) { return (await ensureUser(uid)).balance || 0; }
async function addBalance(uid, amount) {
  if (isMongoConnected) await UserModel.updateOne({ uid: String(uid) }, { $inc: { balance: amount } }, { upsert: true });
  else { (await ensureUser(uid)); jsonDB.users[String(uid)].balance += amount; saveJSON(); }
}
async function setBalance(uid, amount) {
  if (isMongoConnected) await UserModel.updateOne({ uid: String(uid) }, { balance: amount }, { upsert: true });
  else { (await ensureUser(uid)); jsonDB.users[String(uid)].balance = amount; saveJSON(); }
}

async function getExp(uid) { return (await ensureUser(uid)).exp || 0; }
async function addExp(uid, amount) {
  if (isMongoConnected) await UserModel.updateOne({ uid: String(uid) }, { $inc: { exp: amount } }, { upsert: true });
  else { (await ensureUser(uid)); jsonDB.users[String(uid)].exp += amount; saveJSON(); }
}

async function banUserDB(uid, hours = 24, reason = "No reason") {
  const expiry = Date.now() + hours * 3600000;
  if (isMongoConnected) await UserModel.updateOne({ uid: String(uid) }, { banned: true, banExpiry: expiry, banReason: reason }, { upsert: true });
  else { (await ensureUser(uid)); Object.assign(jsonDB.users[String(uid)], { banned: true, banExpiry: expiry, banReason: reason }); saveJSON(); }
}

async function unbanUserDB(uid) {
  if (isMongoConnected) await UserModel.updateOne({ uid: String(uid) }, { banned: false, banExpiry: 0, banReason: "" });
  else { if (jsonDB.users[String(uid)]) { Object.assign(jsonDB.users[String(uid)], { banned: false, banExpiry: 0 }); saveJSON(); } }
}

async function isBanned(uid) {
  const u = await ensureUser(uid);
  if (!u.banned) return false;
  if (u.banExpiry && Date.now() > u.banExpiry) { await unbanUserDB(uid); return false; }
  return true;
}

async function set(key, value) {
  if (isMongoConnected) await KVModel.updateOne({ key }, { value }, { upsert: true });
  else { jsonDB.kv[key] = value; }
}
async function get(key) {
  if (isMongoConnected) { const d = await KVModel.findOne({ key }); return d?.value ?? null; }
  return jsonDB.kv[key] ?? null;
}
async function del(key) {
  if (isMongoConnected) await KVModel.deleteOne({ key });
  else { delete jsonDB.kv[key]; }
}

module.exports = {
  initDatabase, saveJSON,
  getUser, getAllUsers,
  getBalance, addBalance, setBalance,
  getExp, addExp,
  banUserDB, unbanUserDB, isBanned,
  set, get, del,
};
