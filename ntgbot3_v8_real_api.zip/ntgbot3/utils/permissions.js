"use strict";

/**
 * NTG Role System
 * ─────────────────────────────────────────
 *  4  →  Developer  👨‍💻  (devUsers in config)
 *  3  →  Premium    ⭐  (premiumUsers in config)
 *  2  →  Admin      🛡️  (adminBot in config)
 *  0  →  User       👤  (everyone else)
 * ─────────────────────────────────────────
 */

const ROLE_NAMES = {
  4: "Developer 👨‍💻",
  3: "Premium ⭐",
  2: "Admin 🛡️",
  0: "User 👤",
};

const ROLE_REQUIRED_TEXT = {
  4: "Developer only 👨‍💻",
  3: "Premium or above ⭐",
  2: "Admin or above 🛡️",
  0: "Everyone",
};

function getRole(userID) {
  const id = String(userID);
  const { devUsers, adminBot, premiumUsers } = global.NTGBot.config;

  if ((devUsers   || []).includes(id)) return 4;
  if ((adminBot   || []).includes(id)) return 2;
  if ((premiumUsers || []).includes(id)) return 3;
  return 0;
}

function hasRole(userID, required = 0) {
  const role = getRole(userID);
  if (role === 4) return true;   // Developer bypasses everything
  return role >= required;
}

function getRoleName(roleNum) {
  return ROLE_NAMES[roleNum] || "User 👤";
}

function getRoleRequired(roleNum) {
  return ROLE_REQUIRED_TEXT[roleNum] || "Everyone";
}

module.exports = { getRole, hasRole, getRoleName, getRoleRequired };
