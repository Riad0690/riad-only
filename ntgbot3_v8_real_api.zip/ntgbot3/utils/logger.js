"use strict";

const { createLogger, format, transports } = require("winston");
const path = require("path");
const fs   = require("fs");

const logsDir = path.join(__dirname, "../storage/logs");
if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });

// ── ANSI color codes ────────────────────────────────────────────────────────
const C = {
  reset: "\x1b[0m", bold: "\x1b[1m", dim: "\x1b[2m",
  red: "\x1b[31m", green: "\x1b[32m", yellow: "\x1b[33m",
  magenta: "\x1b[35m", cyan: "\x1b[36m", white: "\x1b[37m", black: "\x1b[30m",
  bgRed: "\x1b[41m", bgGreen: "\x1b[42m", bgYellow: "\x1b[43m", bgBlue: "\x1b[44m",
};

// ── Custom levels (must be registered with Winston, not just used) ─────────
const LEVELS = { error: 0, warn: 1, info: 2, cmd: 3, event: 4, db: 5, bot: 6, debug: 7 };

const BADGES = {
  error: `${C.bold}${C.bgRed}${C.white} ERROR ${C.reset}`,
  warn:  `${C.bold}${C.bgYellow}${C.black}  WARN ${C.reset}`,
  info:  `${C.bold}${C.bgBlue}${C.white}  INFO ${C.reset}`,
  cmd:   `${C.bold}${C.bgGreen}${C.black}   CMD ${C.reset}`,
  event: `${C.bold}${C.magenta}${C.white} EVENT ${C.reset}`,
  db:    `${C.bold}${C.cyan}${C.black}    DB ${C.reset}`,
  bot:   `${C.bold}${C.green}${C.black}   BOT ${C.reset}`,
  debug: `${C.dim}${C.white} DEBUG ${C.reset}`,
};

function ts() {
  return new Date().toLocaleString("en-US", {
    timeZone: (global.NTGBot?.config?.timeZone) || "UTC",
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
  }).replace(",", "");
}

const consoleFormat = format.printf(({ level, message }) => {
  const badge = BADGES[level] || `${C.dim}[${String(level).toUpperCase()}]${C.reset}`;
  return `${C.dim}${ts()}${C.reset} ${C.dim}│${C.reset} ${badge} ${C.dim}│${C.reset} ${message}`;
});

const fileFormat = format.printf(({ level, message }) => {
  const clean = String(message).replace(/\x1b\[[0-9;]*m/g, "");
  return `[${ts()}] [${String(level).toUpperCase().padEnd(5)}] ${clean}`;
});

const winstonLogger = createLogger({
  levels: LEVELS,           // ← REQUIRED: registers cmd/event/db/bot so no "Unknown logger level"
  level:  "debug",
  transports: [
    new transports.Console({ format: consoleFormat }),
    new transports.File({
      filename: path.join(logsDir, "combined.log"),
      format:   fileFormat,
      maxsize:  5 * 1024 * 1024,
      maxFiles: 5,
    }),
    new transports.File({
      filename: path.join(logsDir, "error.log"),
      level:    "error",
      format:   fileFormat,
      maxsize:  2 * 1024 * 1024,
      maxFiles: 3,
    }),
  ],
});

const logger = {
  info:  (msg) => winstonLogger.log("info",  msg),
  warn:  (msg) => winstonLogger.log("warn",  msg),
  error: (msg) => winstonLogger.log("error", msg),
  debug: (msg) => winstonLogger.log("debug", msg),

  // ── GoatBot-style incoming message log ────────────────────────────────────
  message: (senderID, threadId, body, isGroup = false) => {
    const preview = body.length > 60 ? `${body.slice(0, 60)}…` : body;
    winstonLogger.log("event",
      `${C.yellow}UID${C.reset}:${senderID} ${C.dim}│${C.reset} ${C.magenta}TID${C.reset}:${threadId} ${isGroup ? "(group)" : "(dm)"} ${C.dim}│${C.reset} "${preview}"`);
  },

  // ── GoatBot-style command execution log ───────────────────────────────────
  command: (cmdName, senderID, threadId, status = true, extra = "") => {
    const statusBadge = status ? `${C.green}✔${C.reset}` : `${C.red}✘ ${extra}${C.reset}`;
    winstonLogger.log("cmd",
      `${C.cyan}${cmdName}${C.reset} ${C.dim}│${C.reset} ${C.yellow}UID${C.reset}:${senderID} ${C.dim}│${C.reset} ${C.magenta}TID${C.reset}:${threadId} ${C.dim}│${C.reset} ${statusBadge}`);
  },

  cmd: (name, user, status) =>
    winstonLogger.log("cmd", `${C.cyan}${name}${C.reset} ← ${C.yellow}@${user}${C.reset} ${status ? `${C.green}✔${C.reset}` : `${C.red}✘${C.reset}`}`),

  event: (name, detail = "") =>
    winstonLogger.log("event", `${C.magenta}${name}${C.reset}${detail ? ` ${C.dim}→ ${detail}${C.reset}` : ""}`),

  db:  (msg) => winstonLogger.log("db",  `${C.cyan}${msg}${C.reset}`),
  bot: (msg) => winstonLogger.log("bot", `${C.green}${msg}${C.reset}`),

  divider: (label = "") => {
    const text = label
      ? `${C.dim}┌─ ${C.reset}${C.bold}${label}${C.reset} ${C.dim}${"─".repeat(Math.max(0, 40 - label.length))}${C.reset}`
      : `${C.dim}${"─".repeat(44)}${C.reset}`;
    console.log(text);
  },
};

module.exports = logger;
