"use strict";

const fs = require("fs");
const path = require("path");

const langDir = path.join(__dirname, "../languages");

function loadLangFile(lang) {
  let filePath = path.join(langDir, `${lang}.lang`);
  if (!fs.existsSync(filePath)) {
    filePath = path.join(langDir, "en.lang");
  }
  const raw = fs.readFileSync(filePath, "utf-8");
  const lines = raw
    .split(/\r?\n/)
    .filter(l => l && !l.trim().startsWith("#") && l.includes("="));
  const obj = {};
  for (const line of lines) {
    const sep = line.indexOf("=");
    const fullKey = line.slice(0, sep).trim();
    const value = line.slice(sep + 1).trim().replace(/\\n/g, "\n");
    const dot = fullKey.indexOf(".");
    const head = fullKey.slice(0, dot);
    const key = fullKey.slice(dot + 1);
    if (!obj[head]) obj[head] = {};
    obj[head][key] = value;
  }
  return obj;
}

function initLanguage() {
  const config = require("../config");
  global.NTGBot.language = loadLangFile(config.language || "en");
}

function getLang(head, key, ...args) {
  // ── 1. Check the command/event's own `langs` object first (GoatBot style) ──
  const cmd = global.NTGBot?.commands?.get(head) || global.NTGBot?.events?.get(head);
  if (cmd?.langs) {
    const langCode = global.NTGBot?.config?.language || "en";
    const ownLangs = cmd.langs[langCode] || cmd.langs.en;
    if (ownLangs?.[key] !== undefined) {
      let text = ownLangs[key];
      for (let i = 0; i < args.length; i++) {
        text = text.replace(new RegExp(`%${i + 1}`, "g"), String(args[i]));
      }
      return text;
    }
  }

  // ── 2. Fall back to the global .lang file (used by handler.* keys etc.) ────
  const langObj = global.NTGBot?.language || {};
  if (!langObj[head]?.[key]) return `[MISSING: ${head}.${key}]`;
  let text = langObj[head][key];
  for (let i = 0; i < args.length; i++) {
    text = text.replace(new RegExp(`%${i + 1}`, "g"), String(args[i]));
  }
  return text;
}

module.exports = { initLanguage, getLang };
