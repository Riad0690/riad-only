"use strict";

const fs   = require("fs");
const path = require("path");

const configPath = path.join(__dirname, "../config/default.json");

/**
 * Persist the current in-memory global.NTGBot.config back to default.json.
 * Call this after mutating role arrays (devUsers, adminBot, premiumUsers)
 * so changes survive a bot restart.
 */
function saveConfig() {
  try {
    const cfg = global.NTGBot.config;
    fs.writeFileSync(configPath, JSON.stringify(cfg, null, 2));
    return true;
  } catch (e) {
    require("./logger").error(`[CONFIG] Failed to save default.json: ${e.message}`);
    return false;
  }
}

/**
 * Add a UID to a role list (devUsers / adminBot / premiumUsers) if not
 * already present, then persist.
 * Returns true if added, false if already existed.
 */
function addToRoleList(listName, uid) {
  const cfg = global.NTGBot.config;
  if (!Array.isArray(cfg[listName])) cfg[listName] = [];
  const id = String(uid);
  if (cfg[listName].map(String).includes(id)) return false;
  cfg[listName].push(id);
  saveConfig();
  return true;
}

/**
 * Remove a UID from a role list, then persist.
 * Returns true if removed, false if it wasn't there.
 */
function removeFromRoleList(listName, uid) {
  const cfg = global.NTGBot.config;
  if (!Array.isArray(cfg[listName])) return false;
  const id = String(uid);
  const before = cfg[listName].length;
  cfg[listName] = cfg[listName].filter(x => String(x) !== id);
  const changed = cfg[listName].length !== before;
  if (changed) saveConfig();
  return changed;
}

module.exports = { saveConfig, addToRoleList, removeFromRoleList };
