"use strict";

const config = require("../config");

function initGlobal() {
  global.NTGBot = {
    // ── Core ──────────────────────────────────────────────────────────────────
    config,
    commands:    new Map(),
    events:      new Map(),
    onReply:     new Map(),
    onReaction:  new Map(),

    // ── Bot info ──────────────────────────────────────────────────────────────
    botID:       null,
    username:    null,
    startTime:   Date.now(),
    version:     "2.0.0",
    author:      "MD RIAD",
    authorUID:   "51704856285",

    // ── Language ──────────────────────────────────────────────────────────────
    language:    {},

    // ── Stats (runtime counters) ──────────────────────────────────────────────
    stats: {
      totalCommands:  0,   // total commands executed since start
      totalErrors:    0,   // total errors since start
      totalMessages:  0,   // total messages received
    },

    // ── Utils (populated after init via populateUtils) ────────────────────────
    utils: {
      getLang:      null,
      getRole:      null,
      hasRole:      null,
      getBalance:   null,
      addBalance:   null,
      setBalance:   null,
      getExp:       null,
      addExp:       null,
      getUser:      null,
      getAllUsers:   null,
      isBanned:     null,
      banUser:      null,
      unbanUser:    null,
      set:          null,
      get:          null,
      del:          null,
      logger:       null,
    },
  };
}

// ── NTG command signature check ───────────────────────────────────────────────
// Every command MUST have config.name + onStart function to pass
function ntgCheck(cmd) {
  if (!cmd)                                            return false;
  if (!cmd.config?.name)                               return false;
  if (!cmd.onStart || typeof cmd.onStart !== "function") return false;
  return true;
}

// ── Populate global.NTGBot.utils after all modules load ───────────────────────
function populateUtils() {
  const { getLang }                                          = require("./language");
  const { getRole, hasRole }                                 = require("./permissions");
  const {
    getBalance, addBalance, setBalance,
    getExp, addExp, getUser, getAllUsers,
    isBanned, banUserDB, unbanUserDB,
    set, get, del,
  }                                                          = require("./database");
  const logger                                               = require("./logger");

  global.NTGBot.utils = {
    getLang,
    getRole, hasRole,
    getBalance, addBalance, setBalance,
    getExp, addExp,
    getUser, getAllUsers,
    isBanned,
    banUser:   banUserDB,
    unbanUser: unbanUserDB,
    set, get, del,
    logger,
  };
}

module.exports = { initGlobal, ntgCheck, populateUtils };
