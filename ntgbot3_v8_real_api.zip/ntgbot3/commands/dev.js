"use strict";

const { addToRoleList, removeFromRoleList } = require("../utils/configWriter");

module.exports = {
  config: {
    name:        "dev",
    aliases:     [],
    version:     "1.0",
    author:      "MD RIAD",
    cooldown:    2,
    role:        4,   // only an existing Developer can add/remove other devs
    description: "Add or remove a Developer (full access, bypasses all role checks)",
    guide:
      "{p}dev add <uid>   — make uid a Developer\n" +
      "{p}dev rmv <uid>   — remove uid from Developer",
    category: "admin",
  },

  langs: {
    en: {
      usage:       "⚠️ Usage: {p}dev add/rmv <uid>",
      missingUid:  "⚠️ Please provide a user ID",
      added:       "✅ UID %1 added as Developer 👨‍💻",
      removed:     "✅ UID %1 removed from Developer",
      already:     "⚠️ UID %1 is already a Developer",
      notIn:       "⚠️ UID %1 is not in the Developer list",
    },
  },

  onStart: async function ({ event, args, message, getLang }) {
    const prefix = global.NTGBot.config.prefix;
    const sub    = args[0]?.toLowerCase();
    const uid    = args[1];

    if (!["add", "rmv", "remove"].includes(sub)) {
      return message.reply(getLang("usage").replace("{p}", prefix));
    }
    if (!uid) return message.reply(getLang("missingUid"));

    if (sub === "add") {
      const added = addToRoleList("devUsers", uid);
      return message.reply(added ? getLang("added", uid) : getLang("already", uid));
    } else {
      const removed = removeFromRoleList("devUsers", uid);
      return message.reply(removed ? getLang("removed", uid) : getLang("notIn", uid));
    }
  },
};
