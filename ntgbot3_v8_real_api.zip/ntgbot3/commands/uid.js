"use strict";

module.exports = {
  config: {
    name:        "uid",
    aliases:     ["id", "myid"],
    version:     "2.0",
    author:      "MD RIAD",
    cooldown:    3,
    role:        0,
    description: "Get your Instagram user ID or another user's",
    category:    "info",
    guide:       "{p}uid  |  {p}uid @username",
  },

  langs: {
    en: {
      yours:    "🪪 Your UID\n━━━━━━━━━━━━━━\nUID      : %1\nUsername : @%2\nName     : %3",
      other:    "🪪 User Info\n━━━━━━━━━━━━━━\nUID      : %1\nUsername : @%2\nName     : %3",
      notFound: "❌ User @%1 not found.",
      error:    "❌ Error: %1",
    },
  },

  onStart: async function ({ api, event, args, message, getLang }) {
    const { senderID } = event;
    const rawTarget    = args[0]?.replace(/^@/, "").trim();

    try {
      if (rawTarget) {
        const info = await api.getUserInfoByUsername(rawTarget);
        if (!info) return message.reply(getLang("notFound", rawTarget));
        message.reply(getLang("other",
          info.pk || info.id || "N/A",
          info.username || rawTarget,
          info.full_name || "N/A",
        ));
      } else {
        const info = await api.getUserInfo(senderID);
        message.reply(getLang("yours",
          info?.pk || senderID,
          info?.username || "N/A",
          info?.full_name || "N/A",
        ));
      }
    } catch (e) {
      message.reply(getLang("error", e.message));
    }
  },
};
