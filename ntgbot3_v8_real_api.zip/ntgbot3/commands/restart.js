"use strict";

module.exports = {
  config: {
    name:        "restart",
    aliases:     ["reboot", "rs"],
    version:     "2.0",
    author:      "MD RIAD",
    cooldown:    10,
    role:        4,   // Developer only
    description: "Restart the bot process",
    category:    "dev",
    guide:       "{p}restart",
  },

  langs: {
    en: {
      confirm:    "🔄 Restarting NTG Bot...\nSee you on the other side! 👋",
    },
  },

  onStart: async function ({ message, getLang }) {
    await message.reply(getLang("confirm"));
    setTimeout(() => process.exit(0), 2000);
  },
};
