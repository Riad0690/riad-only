"use strict";

const { banUserDB, unbanUserDB, addBalance, getAllUsers } = require("../utils/database");
const { reloadCommand }                                   = require("../utils/commandLoader");
const { addToRoleList, removeFromRoleList }                = require("../utils/configWriter");

module.exports = {
  config: {
    name:        "admin",
    aliases:     ["adm"],
    version:     "3.0",
    author:      "MD RIAD",
    cooldown:    2,
    role:        4,   // only Developer can manage admin role / bot admin
    description: "Manage bot admins, bans, money, and bot stats",
    guide:
      "{p}admin add <uid>      — make uid an admin\n" +
      "{p}admin rmv <uid>      — remove uid from admin\n" +
      "{p}admin ban <uid> [hours] [reason]\n" +
      "{p}admin unban <uid>\n" +
      "{p}admin addmoney <uid> <amount>\n" +
      "{p}admin removemoney <uid> <amount>\n" +
      "{p}admin stats\n" +
      "{p}admin reload <cmd>",
    category: "admin",
  },

  onStart: async function ({ api, event, args, getLang }) {
    const { threadId } = event;
    const sub = args[0]?.toLowerCase();

    if (!sub) return api.sendMessage(getLang("title"), threadId);

    // ── Admin role management: .admin add/rmv <uid> ───────────────────────
    if (sub === "add" || sub === "rmv" || sub === "remove") {
      const targetUid = args[1];
      if (!targetUid) return api.sendMessage(getLang("missingUid"), threadId);

      if (sub === "add") {
        const added = addToRoleList("adminBot", targetUid);
        if (!added) return api.sendMessage(getLang("roleAlready", targetUid, "admin"), threadId);
        return api.sendMessage(getLang("roleAdded", targetUid, "admin"), threadId);
      } else {
        const removed = removeFromRoleList("adminBot", targetUid);
        if (!removed) return api.sendMessage(getLang("roleNotIn", targetUid, "admin"), threadId);
        return api.sendMessage(getLang("roleRemoved", targetUid, "admin"), threadId);
      }
    }

    // ── Ban / unban ─────────────────────────────────────────────────────────
    if (sub === "ban") {
      const uid    = args[1];
      const hours  = parseInt(args[2]) || 24;
      const reason = args.slice(3).join(" ") || "No reason";
      if (!uid) return api.sendMessage(getLang("missingUid"), threadId);
      await banUserDB(uid, hours, reason);
      return api.sendMessage(getLang("banned", uid, hours, reason), threadId);
    }

    if (sub === "unban") {
      if (!args[1]) return api.sendMessage(getLang("missingUid"), threadId);
      await unbanUserDB(args[1]);
      return api.sendMessage(getLang("unbanned", args[1]), threadId);
    }

    // ── Money ───────────────────────────────────────────────────────────────
    if (sub === "addmoney") {
      const uid = args[1];
      const amount = parseInt(args[2]);
      if (!uid) return api.sendMessage(getLang("missingUid"), threadId);
      if (isNaN(amount)) return api.sendMessage(getLang("missingAmount"), threadId);
      await addBalance(uid, amount);
      return api.sendMessage(getLang("addedMoney", amount, uid), threadId);
    }

    if (sub === "removemoney") {
      const uid = args[1];
      const amount = parseInt(args[2]);
      if (!uid) return api.sendMessage(getLang("missingUid"), threadId);
      if (isNaN(amount)) return api.sendMessage(getLang("missingAmount"), threadId);
      await addBalance(uid, -amount);
      return api.sendMessage(getLang("removedMoney", amount, uid), threadId);
    }

    // ── Stats ───────────────────────────────────────────────────────────────
    if (sub === "stats") {
      const users  = await getAllUsers();
      const uptime = Date.now() - global.NTGBot.startTime;
      const h = Math.floor(uptime / 3600000);
      const m = Math.floor((uptime % 3600000) / 60000);
      const cfg = global.NTGBot.config;
      return api.sendMessage(getLang("stats",
        users.length,
        users.filter(u => u.banned).length,
        global.NTGBot.commands.size,
        global.NTGBot.events.size,
        h, m,
        global.NTGBot.botID || "NTG",
        (cfg.devUsers || []).length,
        (cfg.adminBot || []).length,
        (cfg.premiumUsers || []).length,
      ), threadId);
    }

    // ── Reload command ─────────────────────────────────────────────────────
    if (sub === "reload") {
      if (!args[1]) return api.sendMessage(getLang("missingCommand"), threadId);
      try {
        const r = reloadCommand(args[1]);
        return api.sendMessage(getLang("reloaded", r), threadId);
      } catch (e) {
        return api.sendMessage(getLang("reloadError", args[1], e.message), threadId);
      }
    }

    api.sendMessage(getLang("unknownSub"), threadId);
  },
};
