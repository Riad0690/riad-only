"use strict";

const axios = require("axios");

async function translate(text, targetLang) {
  const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`;
  const res = await axios.get(url, { timeout: 10000 });
  return {
    text: res.data[0].map(item => item?.[0] || "").join(""),
    from: res.data[2] || "auto",
  };
}

module.exports = {
  config: {
    name:        "translate",
    aliases:     ["trans", "tr"],
    version:     "2.0",
    author:      "MD RIAD",
    cooldown:    3,
    role:        0,
    description: "Translate text to any language",
    category:    "utility",
    guide:       "{p}translate <text>  |  {p}tr <text> -> <lang code>  |  reply a message",
  },

  langs: {
    en: {
      noText:    "❌ Provide text to translate!\nUsage: {p}translate <text> -> <lang>\nExample: {p}translate Hello -> bn",
      result:    "🌐 Translated (%1 → %2)\n\n%3",
      error:     "❌ Translation failed: %1",
    },
  },

  onStart: async function ({ event, args, message, getLang }) {
    const prefix  = global.NTGBot.config.prefix;
    const defLang = global.NTGBot.config.language || "en";

    let text, targetLang;
    const body = args.join(" ");

    // Check if replying to a message
    if (event.replyToItemId && event.replyBody) {
      text = event.replyBody;
      // lang from args if provided, else default
      const arrow = body.indexOf("->");
      targetLang  = arrow !== -1 ? body.slice(arrow + 2).trim() : defLang;
    } else {
      if (!body) return message.reply(getLang("noText").replace("{p}", prefix));
      const arrow = body.lastIndexOf("->");
      if (arrow !== -1 && body.length - arrow <= 7) {
        text       = body.slice(0, arrow).trim();
        targetLang = body.slice(arrow + 2).trim();
      } else {
        text       = body;
        targetLang = defLang;
      }
    }

    if (!text) return message.reply(getLang("noText").replace("{p}", prefix));

    try {
      const { text: translated, from } = await translate(text, targetLang);
      message.reply(getLang("result", from, targetLang, translated));
    } catch (e) {
      message.reply(getLang("error", e.message));
    }
  },
};
