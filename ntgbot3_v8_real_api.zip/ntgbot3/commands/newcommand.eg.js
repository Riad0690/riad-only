/**
 * ╔══════════════════════════════════════════════════════════╗
 * ║          NTG BOT — Command Template                     ║
 * ║          Platform  : Instagram                          ║
 * ║          Author    : MD RIAD                            ║
 * ║                                                         ║
 * ║  HOW TO USE:                                            ║
 * ║  1. Copy this file and rename it (remove ".eg")         ║
 * ║     e.g.  mycommand.eg.js  →  mycommand.js             ║
 * ║  2. Fill in config, langs, and onStart                  ║
 * ║  3. Drop it in the commands/ folder — auto-loaded       ║
 * ║                                                         ║
 * ║  Files ending in ".eg.js" are IGNORED by the loader.   ║
 * ╚══════════════════════════════════════════════════════════╝
 *
 * ROLE LEVELS:
 *   0  →  Everyone
 *   2  →  Admin (adminBot in config)
 *   3  →  Premium (premiumUsers in config)
 *   4  →  Developer (devUsers in config)
 *
 * AVAILABLE IN onStart / onReply / onReaction / onChat:
 *   api          — Instagram API methods (see below)
 *   event        — message event { threadId, senderID, messageId, body, args }
 *   args         — string array of arguments after the command name
 *   message      — shorthand helpers { reply(text), react(emoji), unsend(mid) }
 *   getLang(key, ...params) — get translated string from langs below
 *   bot          — global.NTGBot object (commands, config, stats, ...)
 *
 * API METHODS:
 *   api.sendMessage(text, threadId)
 *   api.sendMessageToUser(text, userId)        — send DM
 *   api.replyToMessage(threadId, text, msgId)
 *   api.sendReaction(emoji, msgId)
 *   api.sendPhotoFromUrl(threadId, url, opts?) — remote image URL
 *   api.sendVideoFromUrl(threadId, url, opts?) — remote video URL
 *   api.sendLocalPhoto(threadId, filePath)     — local image file
 *   api.sendLocalVideo(threadId, filePath)     — local video file
 *   api.sendLocalAudio(threadId, filePath)     — local audio/voice file
 *   api.unsendMessage(threadId, msgId)
 *   api.getLastSentMessage(threadId)
 *   api.getUserInfo(userId)
 *   api.getUserInfoByUsername(username)
 *   api.getThread(threadId)
 *   api.getInbox()
 *   api.markAsSeen(threadId)
 */

"use strict";

module.exports = {

  // ── Config ────────────────────────────────────────────────────────────────
  config: {
    name:        "commandName",     // unique name, used to trigger the command
    aliases:     ["alias1", "alias2"], // optional shortcut names
    version:     "1.0",
    author:      "Your Name",
    cooldown:    5,                 // seconds between uses per user
    role:        0,                 // minimum role required (0 / 2 / 3 / 4)
    description: "Short description of what this command does",
    category:    "categoryName",    // e.g. fun, utility, economy, admin, dev
    guide:       "{p}commandName <arg1> [optional_arg2]",
    //               ↑ {p} is replaced with the bot prefix at runtime
  },

  // ── Language strings ──────────────────────────────────────────────────────
  // getLang("key")           → returns langs.en.key
  // getLang("key", a, b)     → replaces %1 with a, %2 with b, etc.
  langs: {
    en: {
      hello:        "Hello, @%1!",
      noArgs:       "❌ Please provide an argument.\nUsage: {p}commandName <arg>",
      error:        "❌ Something went wrong: %1",
      cooldownHit:  "⏳ Wait a moment before using this again.",
    },
  },

  // ── onStart — runs when someone types the command ─────────────────────────
  onStart: async function ({ api, event, args, message, getLang, bot }) {
    const { threadId, senderID } = event;
    const prefix = bot.config.prefix;

    // Example: require at least one argument
    if (!args[0]) {
      return message.reply(
        getLang("noArgs").replace("{p}", prefix)
      );
    }

    // Your logic here
    message.reply(getLang("hello", args[0]));
  },

  // ── onReply — runs when someone replies to a message this command sent ─────
  // To enable: store the sent messageId in global.NTGBot.onReply inside onStart
  //   global.NTGBot.onReply.set(sentMsgId, { commandName: "commandName", ...extraData });
  //
  // onReply: async function ({ api, event, args, message, getLang, bot, replyData }) {
  //   message.reply("You replied: " + args.join(" "));
  // },

  // ── onReaction — runs when someone reacts to a message this command sent ───
  // To enable: store in global.NTGBot.onReaction inside onStart
  //   global.NTGBot.onReaction.set(sentMsgId, { commandName: "commandName", ...extraData });
  //
  // onReaction: async function ({ api, event, getLang, bot, reactionData }) {
  //   // event.reaction holds the emoji used
  // },

  // ── onChat — runs on EVERY message (no prefix needed) ─────────────────────
  // Use sparingly — it fires for all messages in all threads.
  //
  // onChat: async function ({ api, event, message, bot }) {
  //   // e.g. auto-respond, EXP tracking, keyword detection
  // },
};
