"use strict";

module.exports = {
  config: {
    name:        "debuguser",
    aliases:     ["dbguser"],
    version:     "1.0",
    author:      "MD RIAD",
    cooldown:    3,
    role:        4,   // Developer only — this is a debug/diagnostic tool
    description: "Print the raw getUserInfo response (debug tool for fixing avatar fields)",
    guide:       "{p}debuguser  |  {p}debuguser @username",
    category:    "dev",
  },

  langs: {
    en: {
      error: "❌ Error: %1",
    },
  },

  onStart: async function ({ api, event, args, message, getLang }) {
    const { senderID } = event;
    const rawTarget = args[0]?.replace(/^@/, "").trim();

    try {
      const info = rawTarget
        ? await api.getUserInfoByUsername(rawTarget)
        : await api.getUserInfo(senderID);

      const json = JSON.stringify(info, null, 2);
      // Send in chunks of ~1800 chars to avoid message length limits
      const CHUNK = 1800;
      for (let i = 0; i < json.length; i += CHUNK) {
        await message.reply("```\n" + json.slice(i, i + CHUNK) + "\n```");
      }
    } catch (e) {
      message.reply(getLang("error", e.message));
    }
  },
};
