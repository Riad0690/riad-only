"use strict";

const { addToRoleList, removeFromRoleList } = require("../utils/configWriter");

module.exports = {
  config: {
    name:        "premium",
    aliases:     ["prem"],
    version:     "1.0",
    author:      "MD RIAD",
    cooldown:    2,
    role:        2,   // Admin or above can grant Premium
    description: "Add or remove a Premium user",
    guide:
      "{p}premium add <uid>   — make uid Premium\n" +
      "{p}premium rmv <uid>   — remove uid from Premium",
    category: "admin",
  },

  langs: {
    en: {
      usage:       "⚠️ Usage: {p}premium add/rmv <uid>",
      missingUid:  "⚠️ Please provide a user ID",
      added:       "✅ UID %1 added as Premium ⭐",
      removed:     "✅ UID %1 removed from Premium",
      already:     "⚠️ UID %1 is already Premium",
      notIn:       "⚠️ UID %1 is not in the Premium list",
    },
  },

  onStart: async function ({ event, args, message, getLang }) {
    const prefix = global.NTGBot.config.prefix;
    const sub    = args[0]?.toLowerCase();
    const uid    = args[1];

    if (!["add", "rmv", "remove"].includes(sub)) {
      return message.reply(getLang("usage").replace("{p}", prefix));
    }
    if (!uid) return message.reply(getLang("missingUid"));

    if (sub === "add") {
      const added = addToRoleList("premiumUsers", uid);
      return message.reply(added ? getLang("added", uid) : getLang("already", uid));
    } else {
      const removed = removeFromRoleList("premiumUsers", uid);
      return message.reply(removed ? getLang("removed", uid) : getLang("notIn", uid));
    }
  },
};
