"use strict";

const axios = require("axios");

// ── Replace with your AccuWeather API key ─────────────────────────────────────
// Get free key at: https://developer.accuweather.com
const WEATHER_API_KEY = "YOUR_ACCUWEATHER_API_KEY_HERE";

function fToC(f) { return Math.round((f - 32) / 1.8); }

module.exports = {
  config: {
    name:        "weather",
    aliases:     ["wthr", "w"],
    version:     "2.0",
    author:      "MD RIAD",
    cooldown:    5,
    role:        0,
    description: "Get current weather for any city",
    category:    "utility",
    guide:       "{p}weather <city name>",
  },

  langs: {
    en: {
      noCity:   "❌ Please enter a city name!\nUsage: {p}weather <city>",
      notFound: "❌ City not found: %1",
      noApiKey: "⚠️ Weather API key not configured. Add your AccuWeather key in weather.js",
      error:    "❌ Error: %1",
      result:
        "🌍 Weather for %1\n" +
        "━━━━━━━━━━━━━━━━━━━\n" +
        "☁️  %2\n" +
        "🌡️  Temp: %3°C – %4°C\n" +
        "🤔  Feels like: %5°C – %6°C\n" +
        "🌅  Sunrise: %7\n" +
        "🌄  Sunset: %8\n" +
        "🌞  Day: %9\n" +
        "🌙  Night: %10",
    },
  },

  onStart: async function ({ args, message, getLang }) {
    const prefix = global.NTGBot.config.prefix;
    const city   = args.join(" ").trim();

    if (!city) return message.reply(getLang("noCity").replace("{p}", prefix));
    if (!WEATHER_API_KEY || WEATHER_API_KEY.includes("YOUR_")) {
      return message.reply(getLang("noApiKey"));
    }

    try {
      // Step 1: Location key
      const locRes = await axios.get(
        `https://dataservice.accuweather.com/locations/v1/cities/search`,
        { params: { q: city, apikey: WEATHER_API_KEY, language: "en-us" }, timeout: 10000 }
      );
      if (!locRes.data?.length) return message.reply(getLang("notFound", city));

      const loc     = locRes.data[0];
      const locKey  = loc.Key;
      const locName = `${loc.LocalizedName}, ${loc.Country.LocalizedName}`;

      // Step 2: Forecast
      const fcRes = await axios.get(
        `https://dataservice.accuweather.com/forecasts/v1/daily/1day/${locKey}`,
        { params: { apikey: WEATHER_API_KEY, details: true, language: "en-us" }, timeout: 10000 }
      );
      const day = fcRes.data.DailyForecasts[0];

      const fmt = (iso) => new Date(iso).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true });

      message.reply(getLang("result",
        locName,
        fcRes.data.Headline.Text,
        fToC(day.Temperature.Minimum.Value),
        fToC(day.Temperature.Maximum.Value),
        fToC(day.RealFeelTemperature.Minimum.Value),
        fToC(day.RealFeelTemperature.Maximum.Value),
        fmt(day.Sun.Rise),
        fmt(day.Sun.Set),
        day.Day.LongPhrase,
        day.Night.LongPhrase,
      ));
    } catch (e) {
      message.reply(getLang("error", e.message));
    }
  },
};
