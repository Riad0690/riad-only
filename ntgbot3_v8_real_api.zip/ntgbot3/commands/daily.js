"use strict";

const { addBalance, getBalance, get, set } = require("../utils/database");

module.exports = {
  config: {
    name: "daily",
    aliases: ["claim"],
    version: "1.0",
    author: "MD RIAD",
    cooldown: 0,
    role: 0,
    description: "Claim your daily coins",
    guide: "{p}daily",
    category: "economy",
  },

  onStart: async function ({ api, event, getLang }) {
    const { threadId, senderID } = event;
    const cdKey = `daily:${senderID}`;
    const last = await get(cdKey) || 0;
    const now = Date.now();
    const oneDay = 86400000;

    if (now - last < oneDay) {
      const rem = oneDay - (now - last);
      const h = Math.floor(rem / 3600000);
      const m = Math.floor((rem % 3600000) / 60000);
      return api.sendMessage(getLang("alreadyClaimed", h, m), threadId);
    }

    const reward = Math.floor(Math.random() * 500) + 100;
    await addBalance(senderID, reward);
    await set(cdKey, now);
    api.sendMessage(getLang("claimed", reward, await getBalance(senderID)), threadId);
  },
};
