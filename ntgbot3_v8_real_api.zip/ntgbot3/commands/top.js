"use strict";

const { getAllUsers, getBalance, getExp } = require("../utils/database");

function expToLevel(exp) {
  const DELTA = 5;
  return Math.floor((1 + Math.sqrt(1 + 8 * exp / DELTA)) / 2);
}

module.exports = {
  config: {
    name:        "top",
    aliases:     ["leaderboard", "lb", "rich"],
    version:     "2.0",
    author:      "MD RIAD",
    cooldown:    10,
    role:        0,
    description: "View top users by coins or EXP",
    category:    "economy",
    guide:       "{p}top  |  {p}top exp",
  },

  langs: {
    en: {
      noData:     "No users in the database yet.",
      headerCoin: "💰 Top %1 Richest Users",
      headerExp:  "⭐ Top %1 Users by EXP",
      rowCoin:    "%1. %2 — %3 coins",
      rowExp:     "%1. %2 — LVL %3 (%4 EXP)",
      footer:     "\n━━━━━━━━━━━━━━━━━\nTotal users: %1",
    },
  },

  onStart: async function ({ args, message, getLang }) {
    const mode    = (args[0] || "coins").toLowerCase();
    const isExp   = mode === "exp" || mode === "xp" || mode === "level";
    const LIMIT   = 15;

    const allUsers = await getAllUsers();
    if (!allUsers?.length) return message.reply(getLang("noData"));

    const sorted = [...allUsers].sort((a, b) =>
      isExp ? (b.exp || 0) - (a.exp || 0) : (b.balance || 0) - (a.balance || 0)
    ).slice(0, LIMIT);

    const medals = ["🥇", "🥈", "🥉"];
    const header = isExp
      ? getLang("headerExp", sorted.length)
      : getLang("headerCoin", sorted.length);

    const rows = sorted.map((u, i) => {
      const label = medals[i] || `${i + 1}.`;
      const name  = (u.name || u.uid || "Unknown").slice(0, 18);
      if (isExp) {
        return getLang("rowExp", label, name, expToLevel(u.exp || 0), u.exp || 0);
      }
      return getLang("rowCoin", label, name, (u.balance || 0).toLocaleString());
    });

    message.reply(`${header}\n━━━━━━━━━━━━━━━━━\n${rows.join("\n")}${getLang("footer", allUsers.length)}`);
  },
};
