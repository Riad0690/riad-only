"use strict";

const { execSync } = require("child_process");

function safeExec(cmd) {
  try { return execSync(cmd, { encoding: "utf8", timeout: 3000 }).trim(); }
  catch { return "N/A"; }
}

module.exports = {
  config: {
    name:        "uptime",
    aliases:     ["stats", "status", "up"],
    version:     "2.0",
    author:      "MD RIAD",
    cooldown:    10,
    role:        0,
    description: "Show bot uptime and system stats",
    category:    "system",
    guide:       "{p}uptime",
  },

  langs: {
    en: {
      result:
        "🤖 NTG Bot — System Stats\n" +
        "━━━━━━━━━━━━━━━━━━━━━━━\n" +
        "⏱️  Uptime     : %1d %2h %3m %4s\n" +
        "📶  Ping       : %5ms\n" +
        "📦  Commands   : %6\n" +
        "📨  Messages   : %7\n" +
        "✅  Cmds Run   : %8\n" +
        "❌  Errors     : %9\n" +
        "━━━━━━━━━━━━━━━━━━━━━━━\n" +
        "💾  Memory     : %10MB / %11MB\n" +
        "🔥  CPU        : %12%\n" +
        "💽  Disk       : %13 used\n" +
        "🖥️  Node.js    : %14\n" +
        "━━━━━━━━━━━━━━━━━━━━━━━\n" +
        "🔖  Version    : v%15",
    },
  },

  onStart: async function ({ message, getLang }) {
    const start = Date.now();

    // Uptime
    const up   = process.uptime();
    const days = Math.floor(up / 86400);
    const hrs  = Math.floor((up % 86400) / 3600);
    const mins = Math.floor((up % 3600) / 60);
    const secs = Math.floor(up % 60);

    // Ping (message round-trip approx)
    const ping = Date.now() - start;

    // Memory
    const mem     = process.memoryUsage();
    const usedMB  = (mem.heapUsed / 1024 / 1024).toFixed(1);
    const totalMB = (mem.heapTotal / 1024 / 1024).toFixed(1);

    // System (Linux only, graceful fallback)
    const cpuRaw  = safeExec("top -bn1 | grep '%Cpu' | awk '{print $2 + $4}'");
    const cpu     = isNaN(parseFloat(cpuRaw)) ? "N/A" : `${parseFloat(cpuRaw).toFixed(1)}`;
    const disk    = safeExec("df -h / | tail -1 | awk '{print $5}'");

    // Bot stats
    const bot = global.NTGBot;

    message.reply(getLang("result",
      days, hrs, mins, secs,
      ping,
      bot.commands.size,
      bot.stats?.totalMessages  || 0,
      bot.stats?.totalCommands  || 0,
      bot.stats?.totalErrors    || 0,
      usedMB, totalMB,
      cpu,
      disk,
      process.version,
      bot.version || "2.0.0",
    ));
  },
};
