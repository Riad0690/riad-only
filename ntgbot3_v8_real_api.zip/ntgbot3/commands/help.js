"use strict";

const ROLE_LABEL = { 0: "Everyone", 2: "Admin", 3: "Premium", 4: "Developer" };

module.exports = {
  config: {
    name:        "help",
    aliases:     ["h", "cmds", "commands"],
    version:     "2.0",
    author:      "MD RIAD",
    cooldown:    3,
    role:        0,
    description: "View command list or details about a specific command",
    category:    "info",
    guide:       "{p}help  |  {p}help <command name>",
  },

  langs: {
    en: {
      notFound: "❌ Command \"%1\" not found.\nType {p}help to see all commands.",
      detail:
        "╭───────────────⭓\n" +
        "│ 📦 %1\n" +
        "├───────────────⭔\n" +
        "│ 📝 %2\n" +
        "│ 🏷️  Aliases : %3\n" +
        "│ 🔖 Version : %4\n" +
        "│ 🔐 Role    : %5\n" +
        "│ ⏱️  Cooldown: %6s\n" +
        "│ 👤 Author  : %7\n" +
        "│ 📂 Category: %8\n" +
        "├───────────────⭔\n" +
        "│ ✏️  Usage\n" +
        "│ %9\n" +
        "╰───────────────⭓",
    },
  },

  onStart: async function ({ event, args, message, getLang }) {
    const prefix   = global.NTGBot.config.prefix;
    const commands = global.NTGBot.commands;

    // ── Single command detail view ────────────────────────────────────────
    if (args[0]) {
      const cmd = commands.get(args[0].toLowerCase());
      if (!cmd) {
        return message.reply(getLang("notFound", args[0]).replace("{p}", prefix));
      }
      const c = cmd.config;
      const roleText = ROLE_LABEL[c.role || 0] || "Everyone";
      const guide    = (c.guide || `${prefix}${c.name}`).replace(/\{p\}/g, prefix);

      return message.reply(getLang("detail",
        c.name.toUpperCase(),
        c.description || "No description provided",
        c.aliases?.length ? c.aliases.join(", ") : "None",
        c.version || "1.0",
        roleText,
        c.cooldown ?? 0,
        c.author || "Unknown",
        c.category || "general",
        guide,
      ));
    }

    // ── Full command list, grouped by category ──────────────────────────────
    const cats = {};
    const seen = new Set();
    for (const [, cmd] of commands) {
      if (seen.has(cmd.config.name)) continue;
      seen.add(cmd.config.name);
      const cat = cmd.config.category || "general";
      if (!cats[cat]) cats[cat] = [];
      cats[cat].push(cmd.config.name);
    }

    const sortedCats = Object.keys(cats).sort();

    let msg = `╭───────────────⭓\n`;
    msg += `│ 🤖 NTG BOT — COMMAND LIST\n`;
    msg += `│ 👤 Author: MD RIAD\n`;
    msg += `├───────────────⭔\n`;
    msg += `│ Prefix : ${prefix}\n`;
    msg += `│ Total  : ${seen.size} commands\n`;
    msg += `├───────────────⭔\n`;

    for (const cat of sortedCats) {
      msg += `│ 📂 ${cat.toUpperCase()} (${cats[cat].length})\n`;
      msg += cats[cat].sort().map(c => `│   ${prefix}${c}`).join("\n") + "\n";
    }

    msg += `╰───────────────⭓\n`;
    msg += `» Type ${prefix}help <name> for details`;

    message.reply(msg);
  },
};
