"use strict";

module.exports = {
  config: {
    name: "ping",
    aliases: ["p"],
    version: "1.0",
    author: "MD RIAD",
    cooldown: 3,
    role: 0,
    description: "Check bot response time",
    guide: "{p}ping",
    category: "info",
  },

  onStart: async function ({ api, event, getLang }) {
    const start = Date.now();
    await api.sendMessage(getLang("result", Date.now() - start), event.threadId);
  },
};
