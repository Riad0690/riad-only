"use strict";

const fs   = require("fs");
const path = require("path");
const InstagramChatAPI                   = require("@neoaz07/nkxica").default || require("@neoaz07/nkxica");
const logger                             = require("../utils/logger");
const { getLang }                        = require("../utils/language");
const { loadCommands, reloadCommand }    = require("../utils/commandLoader");
const { loadEvents }                     = require("../utils/eventLoader");
const { initDatabase, isBanned, set, get, getUser } = require("../utils/database");
const { hasRole, getRole, getRoleRequired } = require("../utils/permissions");
const { populateUtils }                  = require("../utils/global");

const COOKIES_PATH = path.join(__dirname, "../cookies.txt");
const spamTracker  = new Map();

// ── Shorthand helpers ─────────────────────────────────────────────────────────
function cfg()          { return global.NTGBot.config; }
function logCfg()       { return cfg().logEvents || {}; }
function hideCfg()      { return cfg().hideNotiMessage || {}; }
function shouldLog(key) { return !logCfg().disableAll && logCfg()[key] !== false; }
function shouldHide(key){ return hideCfg()[key] === true; }

// ─────────────────────────────────────────────────────────────────────────────
class NTGBot {

  /**
   * Build a thin wrapper around the real ica-neokex client (`rawBot`) so the
   * rest of the codebase (commands/events) keeps using the same simple
   * method names regardless of the underlying library's exact API.
   *
   * Real library methods (ica-neokex / @neoaz07/nkxica), confirmed from
   * https://github.com/lazyneoaz/neokex-ica :
   *   bot.sendMessage(threadId, text, opts?)
   *   bot.sendMessageToUser(userId, text)
   *   bot.sendPhoto(threadId, filePath)
   *   bot.sendPhotoFromUrl(threadId, url)
   *   bot.sendVideo(threadId, filePath)
   *   bot.sendVideoFromUrl(threadId, url)
   *   bot.sendReaction(threadId, itemId, emoji)
   *   bot.removeReaction(threadId, itemId)
   *   bot.editMessage(threadId, itemId, text)
   *   bot.unsendMessage(threadId, itemId)
   *   bot.markAsSeen(threadId, itemId)
   *   bot.indicateTyping(threadId, bool)
   *   bot.getUserInfo(userId)
   *   bot.getUserInfoByUsername(username)
   *   bot.getThread(threadId)
   */
  buildApi(rawBot) {
    return {
      sendMessage:           (text, tid)        => rawBot.sendMessage(tid, text),
      sendMessageToUser:     (text, uid)        => rawBot.sendMessageToUser(uid, text),
      replyToMessage:        (tid, text, mid)   => rawBot.sendMessage(tid, text, { replyToItemId: mid }),
      sendReaction:          (emoji, tid, mid)  => rawBot.sendReaction(tid, mid, emoji),
      sendPhotoFromUrl:      (tid, url, opts)   => rawBot.sendPhotoFromUrl(tid, url),
      sendVideoFromUrl:      (tid, url, opts)   => rawBot.sendVideoFromUrl(tid, url),

      // Local file (used by image-generating commands like rank/slap/kiss/pair)
      sendLocalPhoto:        (tid, filePath)    => rawBot.sendPhoto(tid, filePath),
      sendLocalVideo:        (tid, filePath)    => rawBot.sendVideo(tid, filePath),

      unsendMessage:         (tid, mid)         => rawBot.unsendMessage(tid, mid),
      editMessage:           (tid, mid, text)   => rawBot.editMessage(tid, mid, text),
      getUserInfo:           (uid)              => rawBot.getUserInfo(uid),
      getUserInfoByUsername: (u)                => rawBot.getUserInfoByUsername(u),
      getThread:             (tid)              => rawBot.getThread(tid),
      markAsSeen:            (tid, mid)         => rawBot.markAsSeen(tid, mid),
      sendTyping:            (tid)              => rawBot.indicateTyping(tid, true),
      stopTyping:            (tid)              => rawBot.indicateTyping(tid, false),
    };
  }

  // ── Spam detection ────────────────────────────────────────────────────────
  isSpamming(senderID) {
    if (!cfg().spamProtection?.enable) return false;
    const now = Date.now();
    const win = cfg().spamProtection.timeWindow * 1000;
    if (!spamTracker.has(senderID)) spamTracker.set(senderID, []);
    const ts = spamTracker.get(senderID).filter(t => now - t < win);
    ts.push(now);
    spamTracker.set(senderID, ts);
    return ts.length > cfg().spamProtection.commandThreshold;
  }

  // ── Main message handler ──────────────────────────────────────────────────
  // `msg` shape from bot.onMessage callback (per EXAMPLES.md):
  //   { thread_id, item_id, text, is_from_me, message?: { media } }
  async handleMessage(msg, api) {
    const threadId  = msg.thread_id;
    const senderID  = msg.user_id || msg.sender_id || msg.from_id;
    const body      = msg.text || "";
    const messageId = msg.item_id;

    if (msg.is_from_me) return;
    if (!body || !senderID || !threadId) return;

    // ── Stats ──────────────────────────────────────────────────────────────
    global.NTGBot.stats.totalMessages++;

    // ── Log incoming message ───────────────────────────────────────────────
    if (shouldLog("message")) {
      logger.message(senderID, threadId, body, !!msg.isGroup);
    }

    // ── Banned check ───────────────────────────────────────────────────────
    if (await isBanned(senderID)) {
      if (!shouldHide("userBanned")) {
        const u = await getUser(senderID);
        api.sendMessage(
          getLang("handler", "userBanned", u.banReason || "No reason", new Date(u.banExpiry).toLocaleString(), senderID),
          threadId
        ).catch(() => {});
      }
      return;
    }

    // ── Admin-only mode ────────────────────────────────────────────────────
    if (cfg().adminOnly?.enable && !hasRole(senderID, 2)) {
      if (!cfg().adminOnly.hideNotiMessage) {
        api.sendMessage(getLang("handler", "onlyAdminBot"), threadId).catch(() => {});
      }
      return;
    }

    // ── Whitelist mode ─────────────────────────────────────────────────────
    if (cfg().whiteListMode?.enable) {
      const wl = (cfg().whiteListMode.whiteListIds || []).map(String);
      if (!wl.includes(String(senderID))) return;
    }

    // ── Anti-inbox (group only) ────────────────────────────────────────────
    if (cfg().antiInbox && !msg.isGroup) return;

    // ── Spam check ─────────────────────────────────────────────────────────
    if (this.isSpamming(senderID)) {
      if (shouldLog("spam")) logger.warn(`Spam detected | UID: ${senderID} | TID: ${threadId}`);
      if (!shouldHide("spamDetected")) {
        api.sendMessage(getLang("handler", "spamDetected"), threadId).catch(() => {});
      }
      return;
    }

    const args = body.trim().split(/\s+/);

    // ── onChat (runs for every message, all commands) ──────────────────────
    for (const [, cmd] of global.NTGBot.commands) {
      if (cmd.onChat) {
        try {
          await cmd.onChat({
            api,
            event:   { threadId, senderID, messageId, body, args },
            args,
            bot:     global.NTGBot,
            getLang: (k, ...a) => getLang(cmd.config.name, k, ...a),
            message: {
              reply: (text)  => api.sendMessage(text, threadId),
              react: (emoji) => api.sendReaction(emoji, threadId, messageId),
            },
          });
        } catch { /* silent fail for onChat */ }
      }
    }

    // ── Command parser ─────────────────────────────────────────────────────
    const prefix          = cfg().prefix;
    const role            = getRole(senderID);
    const hasPrefix        = body.startsWith(prefix);
    const noPrefixAllowed  = cfg().noPrefix && role >= 2;

    if (!hasPrefix && !noPrefixAllowed) return;

    const cmdArgs      = (hasPrefix ? body.slice(prefix.length) : body).trim().split(/\s+/);
    const commandName  = (cmdArgs.shift() || "").toLowerCase();
    if (!commandName) return;

    // When in noPrefix mode, only treat the message as a command if the
    // first word actually matches a registered command — otherwise normal
    // chat from admins/devs would get silently swallowed.
    if (!hasPrefix && noPrefixAllowed && !global.NTGBot.commands.has(commandName)) {
      return;
    }

    const cmd = global.NTGBot.commands.get(commandName)
             || global.NTGBot.commands.get(
                  [...global.NTGBot.commands.entries()]
                    .find(([, c]) => c.config?.aliases?.includes(commandName))?.[0]
                );

    if (!cmd) {
      if (!shouldHide("commandNotFound")) {
        api.sendMessage(getLang("handler", "commandNotFound", commandName, prefix), threadId).catch(() => {});
      }
      return;
    }

    // ── Role / permission check ────────────────────────────────────────────
    const requiredRole = cmd.config.role || 0;
    if (!hasRole(senderID, requiredRole)) {
      if (!shouldHide("noPermission")) {
        api.sendMessage(
          getLang("handler", "noPermission", commandName, getRoleRequired(requiredRole)),
          threadId
        ).catch(() => {});
      }
      return;
    }

    // ── Cooldown check ─────────────────────────────────────────────────────
    const cdKey    = `cd:${senderID}:${cmd.config.name}`;
    const lastUsed = await get(cdKey) || 0;
    const cooldown = (cmd.config.cooldown || 0) * 1000;
    if (Date.now() - lastUsed < cooldown) {
      const rem = Math.ceil((cooldown - (Date.now() - lastUsed)) / 1000);
      if (!shouldHide("waitingCooldown")) {
        api.sendMessage(getLang("handler", "waitingCooldown", rem, cmd.config.name), threadId).catch(() => {});
      }
      return;
    }
    if (cooldown > 0) await set(cdKey, Date.now());

    // ── Typing indicator ───────────────────────────────────────────────────
    if (cfg().typingIndicator?.enable) {
      try { await api.sendTyping(threadId); } catch {}
      await new Promise(r => setTimeout(r, cfg().typingIndicator.duration || 1500));
      try { await api.stopTyping(threadId); } catch {}
    }

    // ── Build context ──────────────────────────────────────────────────────
    const ctx = {
      api,
      event: { threadId, senderID, messageId, args: cmdArgs, body },
      args:  cmdArgs,
      bot:   global.NTGBot,
      getLang: (k, ...a) => getLang(cmd.config.name, k, ...a),
      message: {
        reply:  (text)         => api.sendMessage(text, threadId),
        react:  (emoji)        => api.sendReaction(emoji, threadId, messageId),
        unsend: ()              => api.unsendMessage(threadId, messageId),
      },
      usersData:   global.NTGBot.utils,
      threadsData: global.NTGBot.utils,
    };

    // ── Execute command ────────────────────────────────────────────────────
    try {
      await cmd.onStart(ctx);
      await api.sendReaction("✅", threadId, messageId).catch(() => {});

      global.NTGBot.stats.totalCommands++;
      if (shouldLog("message")) logger.command(cmd.config.name, senderID, threadId, true);

    } catch (e) {
      global.NTGBot.stats.totalErrors++;
      await api.sendReaction("❌", threadId, messageId).catch(() => {});

      if (shouldLog("commandError")) logger.command(cmd.config.name, senderID, threadId, false, e.message);

      api.sendMessage(
        getLang("handler", "errorOccurred", cmd.config.name, e.message),
        threadId
      ).catch(() => {});

      // Notify devs on error if enabled
      if (cfg().notiWhenError?.enable) {
        const errMsg =
          `❌ Command Error!\n` +
          `${"─".repeat(28)}\n` +
          `📦 Command : ${cmd.config.name}\n` +
          `👤 User    : @${senderID}\n` +
          `💬 Input   : ${body.slice(0, 100)}\n` +
          `❗ Error   : ${e.message}`;

        for (const uid of (cfg().devUsers || [])) {
          api.sendMessageToUser(errMsg, uid).catch(() => {});
        }
      }
    }
  }

  // ── Event dispatcher ──────────────────────────────────────────────────────
  async fireEvent(name, payload, api) {
    const evt = global.NTGBot.events.get(name);
    if (!evt?.onStart) return;
    try {
      await evt.onStart({
        api,
        event:   payload,
        bot:     global.NTGBot,
        getLang: (k, ...a) => getLang(name, k, ...a),
      });
    } catch (e) {
      global.NTGBot.stats.totalErrors++;
      if (shouldLog("eventError")) {
        const tid = payload?.threadId || payload?.thread_id || "N/A";
        const uid = payload?.userId   || payload?.user_id   || payload?.senderID || "N/A";
        logger.error(`[EVT] ${name} | UID: ${uid} | TID: ${tid} → ${e.message}`);
      }
    }
  }

  // ── Login ─────────────────────────────────────────────────────────────────
  async loginBot() {
    if (!fs.existsSync(COOKIES_PATH)) {
      logger.error(getLang("login", "notFoundAccount"));
      process.exit(1);
    }
    logger.info(getLang("login", "loggingIn"));

    const rawBot = new InstagramChatAPI({ showBanner: false });
    await rawBot.loadCookiesFromFile(COOKIES_PATH);

    global.NTGBot.botID   = String(rawBot.getCurrentUserID());
    global.NTGBot.username = rawBot.getCurrentUsername();

    logger.info(getLang("login", "loginSuccess", global.NTGBot.botID));
    return rawBot;
  }

  // ── Start listening ───────────────────────────────────────────────────────
  async startListening(rawBot) {
    const api = this.buildApi(rawBot);

    await this.fireEvent("ready", { botID: global.NTGBot.botID }, api);
    logger.info(getLang("login", "startListening"));

    // ── Incoming message / reaction events ─────────────────────────────────
    rawBot.onMessage((msg) => {
      try { this.handleMessage(msg, api); }
      catch (e) { logger.error("Handler error: " + e.message); }
    });

    rawBot.onError((err) => {
      logger.error(`[BOT ERROR] (${err.type || "unknown"}) ${err.message}`);
      if (err.type === "auth") {
        logger.error("Authentication failed — cookies may be expired. Exiting for restart.");
        process.exit(1);
      }
    });

    rawBot.onSessionExpired(() => {
      logger.error("Session expired — exiting so process manager can restart.");
      process.exit(1);
    });

    rawBot.onCircuitOpen(({ cooldown }) => {
      logger.warn(`Circuit breaker opened — pausing ${cooldown / 1000}s due to repeated errors`);
    });

    rawBot.onCircuitClosed(() => {
      logger.info("Circuit breaker closed — back online");
    });

    rawBot.onShutdown(() => {
      logger.info("Bot shutdown complete");
    });

    // ── Start the resilient polling loop ────────────────────────────────────
    const mqttCfg = cfg().restartListenMqtt || {};
    await rawBot.startListening({
      interval:             5000,
      minInterval:          3000,
      maxInterval:         30000,
      maxConsecutiveErrors:    5,
      circuitCooldown:     60000,
    });

    // ── Periodic polling restart (optional, mirrors old MQTT-restart idea) ──
    if (mqttCfg.enable) {
      setInterval(async () => {
        if (mqttCfg.logNoti) logger.info(getLang("login", "restartMqtt"));
        try {
          await rawBot.restartPolling({ interval: 5000 });
          if (mqttCfg.logNoti) logger.info(getLang("login", "restartMqttSuccess"));
        } catch (e) {
          logger.error("Polling restart error: " + e.message);
        }
      }, mqttCfg.timeRestart || 3600000);
    }

    // ── Auto restart bot process ────────────────────────────────────────────
    const restartCfg = cfg().autoRestart;
    if (restartCfg?.enable && restartCfg.time) {
      setTimeout(() => {
        logger.warn("Auto restart triggered. Shutting down...");
        process.exit(0);
      }, restartCfg.time);
    }
  }

  // ── Boot sequence ─────────────────────────────────────────────────────────
  async boot() {
    populateUtils();
    await initDatabase();
    loadCommands();
    loadEvents();
    const rawBot = await this.loginBot();
    await this.startListening(rawBot);
  }
}

module.exports = NTGBot;
